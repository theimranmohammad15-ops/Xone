import React, { useState, useEffect } from 'react';
import { CreativeBackground } from './components/CreativeBackground';
import { CustomCursor } from './components/CustomCursor';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { IdeaSection } from './components/IdeaSection';
import { CommunitySection } from './components/CommunitySection';
import { ProcessSection } from './components/ProcessSection';
import { SpaceSection } from './components/SpaceSection';
import { FaqSection } from './components/FaqSection';
import { JoinSection } from './components/JoinSection';
import { FinalSection } from './components/FinalSection';
import { Footer } from './components/Footer';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { getPageSeo } from './config/seo';

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname.toLowerCase().replace(/\/+$/, '');
      if (path === '/privacy-policy' || window.location.hash === '#privacy-policy') {
        return '/privacy-policy';
      }
    }
    return '/';
  });

  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname.toLowerCase().replace(/\/+$/, '');
      if (path === '/privacy-policy' || window.location.hash === '#privacy-policy') {
        setCurrentRoute('/privacy-policy');
      } else {
        setCurrentRoute('/');
      }
      window.scrollTo(0, 0);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Centralized Dynamic SEO & Canonical Synchronization across routes
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const pageSeo = getPageSeo(currentRoute);

    // Synchronize page title
    document.title = pageSeo.title;

    // Synchronize meta description
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', pageSeo.description);

    // Prevent duplicate canonical tags and synchronize canonical href to production domain
    const allCanonicals = Array.from(document.querySelectorAll('link[rel="canonical"]'));
    let canonical = document.getElementById('canonical-url') as HTMLLinkElement | null;

    allCanonicals.forEach((link) => {
      if (link !== canonical) {
        link.remove();
      }
    });

    if (!canonical) {
      canonical = document.createElement('link');
      canonical.id = 'canonical-url';
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = pageSeo.canonicalUrl;

    // Synchronize OpenGraph metadata
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute('content', pageSeo.ogTitle);
    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.setAttribute('content', pageSeo.ogDescription);
    const ogUrl = document.getElementById('og-url') || document.querySelector('meta[property="og:url"]');
    if (ogUrl) ogUrl.setAttribute('content', pageSeo.canonicalUrl);

    // Synchronize Twitter metadata
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) twitterTitle.setAttribute('content', pageSeo.ogTitle);
    const twitterDesc = document.querySelector('meta[name="twitter:description"]');
    if (twitterDesc) twitterDesc.setAttribute('content', pageSeo.ogDescription);
  }, [currentRoute]);

  const navigateTo = (path: string) => {
    if (typeof window !== 'undefined') {
      const normalizedPath = path === '/' ? '/' : path.replace(/\/+$/, '');
      window.history.pushState({}, '', normalizedPath);
      setCurrentRoute(normalizedPath);
      window.scrollTo(0, 0);
    }
  };

  const isPrivacyPage = currentRoute === '/privacy-policy';

  return (
    <div className="relative min-h-screen bg-[#080909] text-[#ededed] selection:bg-[#B8F928]/20 selection:text-[#B8F928] overflow-x-hidden font-sans">
      {/* Dynamic Background System */}
      <CreativeBackground />

      {/* Desktop Custom Cursor */}
      <CustomCursor />

      {/* Minimal, Fully Responsive Top Navigation */}
      <Header onNavigate={navigateTo} isPrivacyPage={isPrivacyPage} />

      {/* Main Experience Stream or Dedicated Views */}
      <main className="relative z-10">
        {isPrivacyPage ? (
          <PrivacyPolicy onBack={() => navigateTo('/')} />
        ) : (
          <>
            {/* Hero Section */}
            <Hero />

            {/* Section 2 — About / The Three-Layer Ecosystem */}
            <IdeaSection />

            {/* Section 4 — The Community & Cardless Community Numbers */}
            <CommunitySection />

            {/* Section 5 — What Happens Here */}
            <ProcessSection />

            {/* Section 6 — The Space */}
            <SpaceSection />

            {/* Section 7 — Frequently Asked Questions */}
            <FaqSection />

            {/* Section 8 — Join X - One (Direct WhatsApp CTA) */}
            <JoinSection />

            {/* Final Section */}
            <FinalSection />
          </>
        )}
      </main>

      {/* Premium Left/Right Footer with Tagline, Instagram, Privacy Policy and Sorx Craft credit */}
      <Footer onNavigate={navigateTo} />
    </div>
  );
}
