import React, { useState, useEffect, useRef } from 'react';
import { XOneLogo } from './XOneLogo';
import { ArrowUpRight, Menu, X } from 'lucide-react';
import { WHATSAPP_COMMUNITY_URL } from '../data/community';

interface HeaderProps {
  onNavigate?: (path: string) => void;
  isPrivacyPage?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onNavigate, isPrivacyPage }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const menuButtonRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when clicking outside
  useEffect(() => {
    if (!mobileMenuOpen) return;

    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      const target = event.target as Node;
      if (
        menuRef.current &&
        !menuRef.current.contains(target) &&
        menuButtonRef.current &&
        !menuButtonRef.current.contains(target)
      ) {
        setMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [mobileMenuOpen]);

  // Desktop navigation links (kept exactly as current approved navbar layout + FAQ)
  const desktopNavLinks = [
    { label: 'COMMUNITY', href: '#community' },
    { label: 'SPACE', href: '#space' },
    { label: 'ABOUT', href: '#about' },
    { label: 'FAQ', href: '#faq' },
  ];

  // Mobile floating menu items (as specifically requested + FAQ)
  const mobileNavItems = [
    { label: 'Home', href: '#home' },
    { label: 'Community', href: '#community' },
    { label: 'About Us', href: '#about' },
    { label: 'AI Lab', href: '#ai-lab' },
    { label: 'X-One.bot', href: '#x-one-bot' },
    { label: 'FAQ', href: '#faq' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);

    if (href.startsWith('#')) {
      const targetId = href.substring(1);
      const executeScroll = () => {
        if (!targetId || targetId === 'home') {
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
          // Compensate for sticky navbar height (72px) so headings are cleanly visible
          const navbarHeight = 72;
          const elementPosition = targetElement.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - navbarHeight;
          window.scrollTo({
            top: Math.max(0, offsetPosition),
            behavior: 'smooth',
          });
        }
      };

      if (isPrivacyPage && onNavigate) {
        onNavigate('/');
        // Brief timeout to let the home route render before scrolling
        setTimeout(executeScroll, 120);
      } else {
        executeScroll();
      }
    } else {
      window.open(href, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled || mobileMenuOpen
            ? 'bg-[#080909]/85 backdrop-blur-md border-b border-white/[0.06] py-3 sm:py-3.5 shadow-[0_4px_20px_rgba(0,0,0,0.4)]'
            : 'bg-transparent py-4 sm:py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-12 flex items-center justify-between">
          {/* Left Brand */}
          <a
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="group flex items-center gap-2.5 sm:gap-3 focus:outline-none shrink-0"
            aria-label="X-One – Office for Founders Homepage"
          >
            <XOneLogo size={28} withGlow={false} animated={true} />
            <span className="text-xs sm:text-sm font-semibold tracking-[0.2em] text-white group-hover:text-[#B8F928] transition-colors">
              X - ONE
            </span>
          </a>

          {/* Desktop & Tablet Center Navigation */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8">
            {desktopNavLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-xs font-medium tracking-widest text-white/70 hover:text-white transition-colors uppercase py-1 relative group"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#B8F928] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Desktop & Tablet CTA Button */}
          <div className="hidden md:flex items-center">
            <a
              href={WHATSAPP_COMMUNITY_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/15 bg-white/[0.03] text-xs font-medium tracking-wider text-white hover:border-[#B8F928]/60 hover:bg-[#B8F928]/[0.08] hover:text-[#B8F928] transition-all duration-300 focus:outline-none"
            >
              <span>JOIN X - ONE</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 text-[#B8F928]" />
            </a>
          </div>

          {/* Mobile Right: Menu Button */}
          <div className="flex md:hidden items-center">
            <button
              ref={menuButtonRef}
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="p-2 rounded-lg text-white/80 hover:text-white hover:bg-white/5 active:bg-white/10 focus:outline-none transition-colors"
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5 text-[#B8F928]" />
              ) : (
                <Menu className="w-5 h-5 text-white" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Subtle Mobile Dim Backdrop (Tapping closes the floating menu without full-screen obstruction) */}
      <div
        className={`fixed inset-0 z-40 bg-black/25 backdrop-blur-[2px] transition-opacity duration-300 md:hidden ${
          mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setMobileMenuOpen(false)}
        aria-hidden="true"
      />

      {/* Compact Floating Mobile Navigation Panel (Positioned near top-right under navbar) */}
      <div
        ref={menuRef}
        className={`fixed top-16 right-4 sm:right-6 z-50 w-[230px] sm:w-[260px] rounded-2xl border border-white/[0.1] bg-[#0c0f10]/95 backdrop-blur-2xl shadow-[0_16px_40px_rgba(0,0,0,0.7)] p-2 transition-all duration-300 ease-out md:hidden ${
          mobileMenuOpen
            ? 'opacity-100 translate-y-0 scale-100 pointer-events-auto'
            : 'opacity-0 -translate-y-2 scale-[0.97] pointer-events-none'
        }`}
        role="dialog"
        aria-modal="true"
        aria-label="Navigation Menu"
      >
        {/* Navigation Rows with subtle internal separation */}
        <nav className="flex flex-col divide-y divide-white/[0.05]">
          {mobileNavItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={(e) => handleNavClick(e, item.href)}
              className="flex items-center justify-between px-3.5 py-2.5 text-xs font-medium tracking-wider text-white/80 hover:text-[#B8F928] hover:bg-white/[0.04] active:bg-[#B8F928]/10 rounded-lg transition-colors group"
            >
              <span>{item.label}</span>
              <span className="text-[11px] font-mono text-white/30 group-hover:text-[#B8F928] transition-colors">
                →
              </span>
            </a>
          ))}
        </nav>

        {/* Compact WhatsApp Community Action Row */}
        <div className="pt-2 mt-1 border-t border-white/[0.08]">
          <a
            href={WHATSAPP_COMMUNITY_URL}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setMobileMenuOpen(false)}
            className="flex items-center justify-center gap-2 w-full py-2 px-3 rounded-xl bg-[#B8F928]/10 border border-[#B8F928]/30 text-[11px] font-semibold tracking-wider text-[#B8F928] hover:bg-[#B8F928] hover:text-[#080909] active:scale-95 transition-all"
          >
            <span>JOIN X - ONE</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </>
  );
};

