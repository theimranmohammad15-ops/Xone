import React from 'react';

export const IdeaSection: React.FC = () => {
  return (
    <section
      id="about"
      className="relative w-full py-24 sm:py-28 md:py-36 px-4 sm:px-6 md:px-16 overflow-hidden"
    >
      {/* Anchor for backward compatibility with #the-idea */}
      <span id="the-idea" className="absolute -top-24 left-0 pointer-events-none" aria-hidden="true" />

      {/* Subtle top seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="max-w-4xl mx-auto">
        {/* Single Small Elegant Heading */}
        <h2 className="text-2xl sm:text-3xl md:text-[2.2rem] font-light text-white tracking-tight leading-snug mb-8 sm:mb-10">
          Built for people who build.
        </h2>

        {/* Editorial Narrative with Breathing Room & Naturally Integrated Three Layers */}
        <div className="space-y-6 max-w-2xl font-light text-base sm:text-lg md:text-[1.125rem]">
          {/* Confident opening statement */}
          <p className="text-white/90 text-lg sm:text-xl md:text-[1.25rem] leading-relaxed">
            X-One is being built as a digital innovation ecosystem and founder space where an idea doesn&apos;t have to stop because someone lacks the team, resources or direction to take it forward.
          </p>

          {/* Layer 01 & 02: Community & AI Lab */}
          <div className="relative">
            <span id="ai-lab" className="absolute -top-24 sm:-top-28 left-0 pointer-events-none" aria-hidden="true" />
            <p className="text-white/65 leading-[1.85]">
              The first layer is the <span className="font-medium text-white">X-One Founder Community</span> — a startup collaboration community where founders, creators, developers and entrepreneurs across Bihar and beyond exchange frameworks, strategy and market thinking. The second is <span className="font-medium text-white">X-One AI Lab</span>, our research space exploring practical AI tools for founders, rapid prototyping, and automated workflows.
            </p>
          </div>

          {/* Layer 03: X-One.bot */}
          <div className="relative">
            <span id="x-one-bot" className="absolute -top-24 sm:-top-28 left-0 pointer-events-none" aria-hidden="true" />
            <p className="text-white/65 leading-[1.85]">
              And the third is <span className="font-medium text-[#B8F928]">X-One.bot</span>, an AI-powered digital office currently in active development, designed to coordinate a specialized AI team for founders — from an AI co-founder and developer to a designer, marketer and more — so one command moves an idea towards real work and execution.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

