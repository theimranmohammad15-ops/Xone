import React from 'react';
import { XOneLogo } from './XOneLogo';

export const FinalSection: React.FC = () => {
  return (
    <section className="relative w-full py-28 sm:py-40 md:py-48 px-4 sm:px-6 md:px-12 overflow-hidden flex flex-col items-center justify-center text-center select-none">
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="relative z-10 max-w-xl mx-auto flex flex-col items-center">
        {/* X - One logo with restrained illumination */}
        <div className="mb-6 relative group">
          <div className="absolute -inset-5 bg-[#B8F928]/15 blur-xl rounded-full opacity-50 group-hover:opacity-80 transition-opacity duration-700 pointer-events-none" />
          <XOneLogo size={68} withGlow={true} animated={true} className="relative z-10" />
        </div>

        {/* Brand Name */}
        <div className="text-xl sm:text-2xl font-semibold tracking-[0.3em] text-white uppercase mb-3 pl-[0.3em]">
          X - ONE
        </div>

        {/* Small Tagline Statement */}
        <p className="text-xs sm:text-sm font-light tracking-[0.25em] text-white/45 uppercase pl-[0.25em]">
          A space for people who build the future.
        </p>
      </div>
    </section>
  );
};
