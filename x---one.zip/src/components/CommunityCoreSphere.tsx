import React, { useEffect, useRef, useState } from 'react';

interface CommunityCoreSphereProps {
  className?: string;
}

interface Node3D {
  x: number;
  y: number;
  z: number;
  size: number;
  isGreen: boolean;
  pulsePhase: number;
  pulseSpeed: number;
  connections: number[];
}

export const CommunityCoreSphere: React.FC<CommunityCoreSphereProps> = ({ className = '' }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') {
      setInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry) {
          setInView(entry.isIntersecting);
        }
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.parentElement?.clientWidth || 440;
    let height = width;
    let isMobile = window.innerWidth < 768;
    let isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

    // Accessibility
    const motionQuery = typeof window.matchMedia === 'function' 
      ? window.matchMedia('(prefers-reduced-motion: reduce)') 
      : null;
    let isReducedMotion = motionQuery?.matches ?? false;

    const handleMotionChange = (e: MediaQueryListEvent) => {
      isReducedMotion = e.matches;
      if (isReducedMotion) {
        drawFrame(0);
      }
    };
    motionQuery?.addEventListener?.('change', handleMotionChange);

    // Mouse Tracking for subtle desktop interaction
    const mouse = {
      x: 0,
      y: 0,
      targetX: 0,
      targetY: 0,
    };

    // Scroll parallax tracking
    const scrollState = {
      offset: 0,
      targetOffset: 0,
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isTouch || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const nx = (e.clientX - (rect.left + rect.width / 2)) / (rect.width / 2);
      const ny = (e.clientY - (rect.top + rect.height / 2)) / (rect.height / 2);
      mouse.targetX = Math.max(-1, Math.min(1, nx));
      mouse.targetY = Math.max(-1, Math.min(1, ny));
    };

    const handleScroll = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const viewportH = window.innerHeight || 800;
      const progress = (rect.top + rect.height / 2) / viewportH - 0.5;
      scrollState.targetOffset = progress;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });

    // Set Canvas Dimensions
    const setDimensions = () => {
      if (!containerRef.current) return;
      const containerW = containerRef.current.clientWidth || containerRef.current.parentElement?.clientWidth || 380;
      isMobile = window.innerWidth < 768;
      isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

      // Generous size for clear transparent glass visibility
      const targetW = containerW > 40 ? Math.min(containerW, isMobile ? 320 : 440) : (isMobile ? 320 : 420);
      width = Math.max(280, targetW);
      height = width;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    setDimensions();
    window.addEventListener('resize', setDimensions);

    // Generate 3D Spherical Network Data (60-70 nodes)
    const NODE_COUNT = isMobile ? 44 : 64;
    const nodes: Node3D[] = [];

    // Golden spiral distribution on sphere surface
    const phi = (1 + Math.sqrt(5)) / 2;
    for (let i = 0; i < NODE_COUNT; i++) {
      const theta = (2 * Math.PI * i) / phi;
      const y = 1 - (i / (NODE_COUNT - 1)) * 2; // -1 to 1
      const radiusAtY = Math.sqrt(Math.max(0, 1 - y * y));
      const x = Math.cos(theta) * radiusAtY;
      const z = Math.sin(theta) * radiusAtY;

      nodes.push({
        x,
        y,
        z,
        size: Math.random() * 1.1 + 0.8,
        isGreen: Math.random() > 0.62, // ~38% X-One green accent nodes
        pulsePhase: Math.random() * Math.PI * 2,
        pulseSpeed: Math.random() * 0.03 + 0.015,
        connections: [],
      });
    }

    // Connect close neighbors
    for (let i = 0; i < nodes.length; i++) {
      const distances: { index: number; dist: number }[] = [];
      for (let j = 0; j < nodes.length; j++) {
        if (i === j) continue;
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dz = nodes[i].z - nodes[j].z;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 0.64) {
          distances.push({ index: j, dist: d });
        }
      }
      distances.sort((a, b) => a.dist - b.dist);
      nodes[i].connections = distances.slice(0, 2).map((d) => d.index);
    }

    // Latitude rings definition (in radians)
    const latitudes = [-0.85, -0.55, -0.25, 0, 0.25, 0.55, 0.85];
    // Longitude meridians (in radians)
    const meridianCount = 8;
    const meridians: number[] = [];
    for (let i = 0; i < meridianCount; i++) {
      meridians.push((Math.PI * 2 * i) / meridianCount);
    }

    let rotY = 0;
    let rotX = 0.24; // subtle natural downward tilt
    let floatPhase = 0;
    let orbitAngle = 0;
    let animationFrameId: number;

    const drawFrame = (_time: number) => {
      if (!ctx || width <= 20 || height <= 20) return;

      try {
        ctx.clearRect(0, 0, width, height);

        const cx = width / 2;
        // Gentle vertical floating displacement
        const floatY = isReducedMotion ? 0 : Math.sin(floatPhase) * (isMobile ? 3 : 5.5);
        const cy = height / 2 + floatY;
        const R = Math.max(15, (width * 0.5) * (isMobile ? 0.62 : 0.58));
        const orbitR = R * 1.36; // Single orbital line radius

        // Mouse influence on rotation angles (subtle & elegant)
        const targetRotX = 0.24 + mouse.y * 0.16;
        const targetRotY = rotY + mouse.x * 0.12;

        // 3D rotation projection helper
        const project = (x: number, y: number, z: number, radius = R) => {
          // Rotate around X
          const y1 = y * Math.cos(targetRotX) - z * Math.sin(targetRotX);
          const z1 = y * Math.sin(targetRotX) + z * Math.cos(targetRotX);
          const x1 = x;

          // Rotate around Y
          const x2 = x1 * Math.cos(targetRotY) + z1 * Math.sin(targetRotY);
          const z2 = -x1 * Math.sin(targetRotY) + z1 * Math.cos(targetRotY);
          const y2 = y1;

          return {
            px: cx + x2 * radius,
            py: cy + y2 * radius,
            pz: z2, // -1 (back) to +1 (front)
          };
        };

        // ==========================================
        // 1. SOFT VOLUMETRIC GLOW & SHADOW BEHIND SPHERE
        // ==========================================
        // Soft ambient drop shadow (restrained so background passes through)
        const shadowGrad = ctx.createRadialGradient(
          cx,
          cy + 14,
          Math.max(0.1, R * 0.2),
          cx,
          cy + 14,
          Math.max(1, R * 1.35)
        );
        shadowGrad.addColorStop(0, 'rgba(4, 5, 5, 0.45)');
        shadowGrad.addColorStop(0.6, 'rgba(6, 7, 7, 0.18)');
        shadowGrad.addColorStop(1, 'rgba(8, 9, 9, 0)');
        ctx.fillStyle = shadowGrad;
        ctx.fillRect(0, 0, width, height);

        // Atmospheric outer glow (subtle emerald & restrained X-One lime)
        const glowGrad = ctx.createRadialGradient(
          cx,
          cy,
          Math.max(0.1, R * 0.75),
          cx,
          cy,
          Math.max(1, R * 1.55)
        );
        glowGrad.addColorStop(0, 'rgba(184, 249, 40, 0.12)');
        glowGrad.addColorStop(0.35, 'rgba(45, 95, 60, 0.06)');
        glowGrad.addColorStop(0.7, 'rgba(18, 38, 26, 0.02)');
        glowGrad.addColorStop(1, 'rgba(8, 9, 9, 0)');
        ctx.fillStyle = glowGrad;
        ctx.fillRect(0, 0, width, height);

      // ==========================================
      // 2. SINGLE ORBITAL LINE — BACK HALF (pz < 0)
      // ==========================================
      // The single orbit circles naturally around the sphere with a 3D inclination (~28° tilt)
      const orbitTiltX = 0.48; // 3D perspective angle
      const orbitSteps = 72;
      const orbitPoints: { px: number; py: number; pz: number }[] = [];

      for (let i = 0; i <= orbitSteps; i++) {
        const theta = (Math.PI * 2 * i) / orbitSteps + orbitAngle;
        const ox = Math.cos(theta);
        const oy = Math.sin(theta) * Math.sin(orbitTiltX);
        const oz = Math.sin(theta) * Math.cos(orbitTiltX);
        orbitPoints.push(project(ox, oy, oz, orbitR));
      }

      // Draw back segments of the orbital line (behind the sphere)
      ctx.lineWidth = 0.85;
      for (let i = 0; i < orbitSteps; i++) {
        const p1 = orbitPoints[i];
        const p2 = orbitPoints[i + 1];
        if (p1.pz < 0 || p2.pz < 0) {
          ctx.beginPath();
          ctx.moveTo(p1.px, p1.py);
          ctx.lineTo(p2.px, p2.py);
          // Very faint behind sphere
          ctx.strokeStyle = 'rgba(184, 249, 40, 0.12)';
          ctx.stroke();
        }
      }

      // ==========================================
      // 3. TRANSPARENT GLASS SPHERE BODY (CLIPPED)
      // ==========================================
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.clip();

      // PASS 3A: INTERNAL BACK-FACING NETWORK (VISIBLE THROUGH GLASS)
      // Because the glass is 60-70% transparent, back-hemisphere lines & nodes are visible!
      // Back Latitude Rings
      ctx.lineWidth = 0.7;
      for (const lat of latitudes) {
        const y = Math.sin(lat);
        const ringR = Math.cos(lat);
        const steps = 30;
        let started = false;

        ctx.beginPath();
        for (let i = 0; i <= steps; i++) {
          const theta = (Math.PI * 2 * i) / steps;
          const x = Math.cos(theta) * ringR;
          const z = Math.sin(theta) * ringR;
          const p = project(x, y, z);

          if (p.pz <= 0) {
            if (!started) {
              ctx.moveTo(p.px, p.py);
              started = true;
            } else {
              ctx.lineTo(p.px, p.py);
            }
          } else {
            started = false;
          }
        }
        ctx.strokeStyle = 'rgba(200, 220, 235, 0.035)';
        ctx.stroke();
      }

      // Back Nodes & Connections
      for (let i = 0; i < nodes.length; i++) {
        const p1 = project(nodes[i].x, nodes[i].y, nodes[i].z);
        if (p1.pz > 0) continue; // Only back nodes

        for (const targetIdx of nodes[i].connections) {
          if (targetIdx <= i) continue;
          const targetNode = nodes[targetIdx];
          const p2 = project(targetNode.x, targetNode.y, targetNode.z);
          if (p2.pz > 0) continue;

          ctx.beginPath();
          ctx.moveTo(p1.px, p1.py);
          ctx.lineTo(p2.px, p2.py);
          ctx.strokeStyle = 'rgba(184, 249, 40, 0.08)';
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }

        // Back node dot
        ctx.fillStyle = nodes[i].isGreen
          ? 'rgba(184, 249, 40, 0.22)'
          : 'rgba(215, 230, 245, 0.16)';
        ctx.beginPath();
        ctx.arc(p1.px, p1.py, nodes[i].size * 0.7, 0, Math.PI * 2);
        ctx.fill();
      }

      // PASS 3B: SEMI-TRANSPARENT GLASS MEDIUM (60–70% TRANSPARENCY)
      // Smooth radial gradient creating realistic dark smoky glass with high transparency at center
      const glassGrad = ctx.createRadialGradient(
        cx - R * 0.2,
        cy - R * 0.25,
        Math.max(0.1, R * 0.05),
        cx,
        cy,
        Math.max(1, R * 1.02)
      );
      // High transparency in the center: allows ~68% of the website's atmospheric background to pass through!
      glassGrad.addColorStop(0, 'rgba(12, 16, 17, 0.32)');
      glassGrad.addColorStop(0.55, 'rgba(15, 20, 22, 0.44)');
      glassGrad.addColorStop(0.85, 'rgba(24, 32, 34, 0.62)');
      glassGrad.addColorStop(1, 'rgba(32, 44, 46, 0.75)'); // Edge glass thickness

      ctx.fillStyle = glassGrad;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

      // Glass specular reflection highlight across upper curved glass surface
      const glassSpecular = ctx.createLinearGradient(
        cx - R * 0.6,
        cy - R * 0.8,
        cx + R * 0.4,
        cy + R * 0.3
      );
      glassSpecular.addColorStop(0, 'rgba(235, 245, 255, 0.13)');
      glassSpecular.addColorStop(0.35, 'rgba(200, 225, 245, 0.04)');
      glassSpecular.addColorStop(0.7, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = glassSpecular;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

      // Subtle lower-right green glass ambient refraction
      const glassRefract = ctx.createRadialGradient(
        cx + R * 0.3,
        cy + R * 0.45,
        0,
        cx,
        cy,
        Math.max(1, R)
      );
      glassRefract.addColorStop(0, 'rgba(184, 249, 40, 0.07)');
      glassRefract.addColorStop(0.5, 'rgba(184, 249, 40, 0.02)');
      glassRefract.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glassRefract;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

      // PASS 3C: INTERNAL FRONT-FACING NETWORK (CRISP & LUMINOUS)
      // Front Latitude Parallels
      ctx.lineWidth = 0.8;
      for (const lat of latitudes) {
        const y = Math.sin(lat);
        const ringR = Math.cos(lat);
        const steps = 36;
        let started = false;

        ctx.beginPath();
        for (let i = 0; i <= steps; i++) {
          const theta = (Math.PI * 2 * i) / steps;
          const x = Math.cos(theta) * ringR;
          const z = Math.sin(theta) * ringR;
          const p = project(x, y, z);

          if (p.pz > -0.05) {
            if (!started) {
              ctx.moveTo(p.px, p.py);
              started = true;
            } else {
              ctx.lineTo(p.px, p.py);
            }
          } else {
            started = false;
          }
        }
        ctx.strokeStyle = 'rgba(215, 230, 245, 0.085)';
        ctx.stroke();
      }

      // Front Longitude Meridians
      for (const lon of meridians) {
        const steps = 32;
        let started = false;

        ctx.beginPath();
        for (let i = 0; i <= steps; i++) {
          const lat = -Math.PI / 2 + (Math.PI * i) / steps;
          const y = Math.sin(lat);
          const ringR = Math.cos(lat);
          const x = Math.cos(lon) * ringR;
          const z = Math.sin(lon) * ringR;
          const p = project(x, y, z);

          if (p.pz > -0.05) {
            if (!started) {
              ctx.moveTo(p.px, p.py);
              started = true;
            } else {
              ctx.lineTo(p.px, p.py);
            }
          } else {
            started = false;
          }
        }
        ctx.strokeStyle = 'rgba(215, 230, 245, 0.07)';
        ctx.stroke();
      }

      // Tilted Geodesic Inner Community Core Path
      const gc = { tiltX: 0.52, tiltY: 0.38, color: 'rgba(184, 249, 40, 0.22)' };
      ctx.beginPath();
      const steps = 44;
      let started = false;
      for (let i = 0; i <= steps; i++) {
        const a = (Math.PI * 2 * i) / steps;
        const bx = Math.cos(a);
        const by = Math.sin(a) * Math.cos(gc.tiltX);
        const bz = Math.sin(a) * Math.sin(gc.tiltX);
        const x = bx * Math.cos(gc.tiltY) + bz * Math.sin(gc.tiltY);
        const y = by;
        const z = -bx * Math.sin(gc.tiltY) + bz * Math.cos(gc.tiltY);
        const p = project(x, y, z);

        if (p.pz > -0.05) {
          if (!started) {
            ctx.moveTo(p.px, p.py);
            started = true;
          } else {
            ctx.lineTo(p.px, p.py);
          }
        } else {
          started = false;
        }
      }
      ctx.strokeStyle = gc.color;
      ctx.lineWidth = 0.95;
      ctx.stroke();

      // Interconnected Filament Arcs (Front Hemisphere)
      for (let i = 0; i < nodes.length; i++) {
        const p1 = project(nodes[i].x, nodes[i].y, nodes[i].z);
        if (p1.pz < -0.05) continue;

        for (const targetIdx of nodes[i].connections) {
          if (targetIdx <= i) continue;
          const targetNode = nodes[targetIdx];
          const p2 = project(targetNode.x, targetNode.y, targetNode.z);
          if (p2.pz < -0.05) continue;

          const avgZ = (p1.pz + p2.pz) / 2;
          const depthAlpha = Math.max(0, (avgZ + 0.1) / 1.1);
          const isGreenEdge = nodes[i].isGreen || targetNode.isGreen;

          ctx.beginPath();
          ctx.moveTo(p1.px, p1.py);
          ctx.lineTo(p2.px, p2.py);
          ctx.strokeStyle = isGreenEdge
            ? `rgba(184, 249, 40, ${depthAlpha * 0.38})`
            : `rgba(220, 235, 250, ${depthAlpha * 0.24})`;
          ctx.lineWidth = 0.9;
          ctx.stroke();
        }
      }

      // Front Community Network Nodes (Points)
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        const p = project(node.x, node.y, node.z);
        if (p.pz < -0.05) continue;

        const depthAlpha = Math.max(0.15, (p.pz + 0.1) / 1.1);
        node.pulsePhase += node.pulseSpeed;
        const pulse = (Math.sin(node.pulsePhase) + 1) * 0.5;

        const baseAlpha = depthAlpha * (0.7 + pulse * 0.3);
        const nodeSize = node.size * (0.85 + depthAlpha * 0.4);

        // Soft halo on green nodes
        if (node.isGreen && p.pz > 0.12) {
          ctx.fillStyle = `rgba(184, 249, 40, ${baseAlpha * 0.35})`;
          ctx.beginPath();
          ctx.arc(p.px, p.py, nodeSize * 2.6, 0, Math.PI * 2);
          ctx.fill();
        }

        // Core Node Dot
        ctx.fillStyle = node.isGreen
          ? `rgba(184, 249, 40, ${baseAlpha})`
          : `rgba(238, 246, 255, ${baseAlpha * 0.92})`;
        ctx.beginPath();
        ctx.arc(p.px, p.py, nodeSize, 0, Math.PI * 2);
        ctx.fill();
      }

      // Inner glass edge refraction ring (inside clip)
      ctx.beginPath();
      ctx.arc(cx, cy, R - 1, 0, Math.PI * 2);
      ctx.lineWidth = 1.5;
      const innerRimGrad = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
      innerRimGrad.addColorStop(0, 'rgba(235, 245, 255, 0.28)');
      innerRimGrad.addColorStop(0.4, 'rgba(184, 249, 40, 0.22)');
      innerRimGrad.addColorStop(0.8, 'rgba(25, 55, 35, 0.12)');
      innerRimGrad.addColorStop(1, 'rgba(8, 9, 9, 0)');
      ctx.strokeStyle = innerRimGrad;
      ctx.stroke();

      ctx.restore(); // Restore unclipped state

      // ==========================================
      // 4. SINGLE ORBITAL LINE — FRONT HALF (pz >= 0)
      // ==========================================
      // Passes gracefully in FRONT of the transparent sphere
      ctx.lineWidth = 1;
      for (let i = 0; i < orbitSteps; i++) {
        const p1 = orbitPoints[i];
        const p2 = orbitPoints[i + 1];
        if (p1.pz >= 0 && p2.pz >= 0) {
          ctx.beginPath();
          ctx.moveTo(p1.px, p1.py);
          ctx.lineTo(p2.px, p2.py);

          // Luminous platinum to subtle X-One green gradient
          const orbitAlpha = 0.35 + p1.pz * 0.45;
          ctx.strokeStyle = `rgba(184, 249, 40, ${orbitAlpha * 0.75})`;
          ctx.stroke();
        }
      }

      // Luminous Satellite Beacon traversing the single orbit
      const beaconTheta = (orbitAngle * 1.5) % (Math.PI * 2);
      const bx = Math.cos(beaconTheta);
      const by = Math.sin(beaconTheta) * Math.sin(orbitTiltX);
      const bz = Math.sin(beaconTheta) * Math.cos(orbitTiltX);
      const bp = project(bx, by, bz, orbitR);

      if (bp.pz >= -0.1) {
        // Beacon soft glow halo
        ctx.fillStyle = 'rgba(184, 249, 40, 0.3)';
        ctx.beginPath();
        ctx.arc(bp.px, bp.py, 4.5, 0, Math.PI * 2);
        ctx.fill();

        // Beacon bright core
        ctx.fillStyle = '#B8F928';
        ctx.beginPath();
        ctx.arc(bp.px, bp.py, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }

      // ==========================================
      // 5. EXTERNAL GLASS RIM & ATMOSPHERIC HALO
      // ==========================================
      // Crisp 1px razor-sharp outer glass rim
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.lineWidth = 1.1;
      const outerRimGrad = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
      outerRimGrad.addColorStop(0, 'rgba(240, 248, 255, 0.52)');
      outerRimGrad.addColorStop(0.35, 'rgba(184, 249, 40, 0.32)');
      outerRimGrad.addColorStop(0.7, 'rgba(40, 75, 50, 0.18)');
      outerRimGrad.addColorStop(1, 'rgba(8, 9, 9, 0)');
      ctx.strokeStyle = outerRimGrad;
      ctx.stroke();

      // Outer soft glass corona
      ctx.beginPath();
      ctx.arc(cx, cy, R + 1, 0, Math.PI * 2);
      ctx.lineWidth = 2.2;
      const coronaGrad = ctx.createRadialGradient(
        cx,
        cy,
        Math.max(0.1, R - 2),
        cx,
        cy,
        Math.max(1, R + 6)
      );
      coronaGrad.addColorStop(0, 'rgba(184, 249, 40, 0.16)');
      coronaGrad.addColorStop(0.6, 'rgba(184, 249, 40, 0.05)');
      coronaGrad.addColorStop(1, 'rgba(184, 249, 40, 0)');
      ctx.strokeStyle = coronaGrad;
      ctx.stroke();
    } catch (err) {
      // Gracefully catch any unexpected canvas error
      console.error('CommunityCoreSphere draw error:', err);
    }
  };

    // Animation Loop
    const loop = (_time: number) => {
      // Easing on mouse tracking
      mouse.x += (mouse.targetX - mouse.x) * 0.045;
      mouse.y += (mouse.targetY - mouse.y) * 0.045;

      // Scroll parallax easing
      scrollState.offset += (scrollState.targetOffset - scrollState.offset) * 0.055;

      if (!isReducedMotion) {
        // Continuous slow sphere rotation
        rotY += 0.003;
        // Continuous slow vertical float
        floatPhase += 0.02;
        // Continuous slow single orbit revolution
        orbitAngle += 0.004;
      }

      drawFrame(_time);

      if (!isReducedMotion && inView) {
        animationFrameId = requestAnimationFrame(loop);
      }
    };

    if (inView) {
      if (isReducedMotion) {
        drawFrame(0);
      } else {
        animationFrameId = requestAnimationFrame(loop);
      }
    } else {
      drawFrame(0);
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', setDimensions);
      motionQuery?.removeEventListener?.('change', handleMotionChange);
    };
  }, [inView]);

  return (
    <div
      ref={containerRef}
      className={`relative flex items-center justify-center select-none w-full min-h-[300px] ${className}`}
    >
      <canvas
        ref={canvasRef}
        className="block relative z-10 transition-transform duration-700 ease-out"
        style={{ pointerEvents: 'none' }}
      />
    </div>
  );
};
