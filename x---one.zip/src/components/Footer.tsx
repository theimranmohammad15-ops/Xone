import React from 'react';
import { XOneLogo } from './XOneLogo';
import { Instagram } from 'lucide-react';

interface FooterProps {
  onNavigate?: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handlePrivacyClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    if (onNavigate) {
      onNavigate('/privacy-policy');
    } else {
      window.history.pushState({}, '', '/privacy-policy');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  return (
    <footer className="w-full bg-transparent pt-16 sm:pt-20 md:pt-24 pb-12 px-4 sm:px-6 md:px-12 select-none relative z-10">
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="max-w-6xl mx-auto">
        {/* Main Two-Column Layout (Desktop/Tablet) / Stacked (Mobile) */}
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-10 md:gap-16 pb-16">
          {/* LEFT SIDE: Brand, Tagline, Supporting Text */}
          <div className="flex flex-col items-start max-w-md">
            {/* Logo and Brand Name */}
            <div className="flex items-center gap-3 mb-3">
              <XOneLogo size={26} withGlow={false} />
              <span className="text-base sm:text-lg font-semibold tracking-[0.25em] text-white uppercase">
                X - One
              </span>
            </div>

            {/* Scale Beyond Imagination — Small, understated, on ONE SINGLE LINE */}
            <div className="text-xs sm:text-sm font-light tracking-[0.2em] text-white/55 uppercase whitespace-nowrap mb-3">
              Scale Beyond Imagination
            </div>

            {/* Supporting Line */}
            <p className="text-xs sm:text-sm text-white/40 font-light leading-relaxed">
              An office and founder community for people who create, build and think forward.
            </p>
          </div>

          {/* RIGHT SIDE: Navigation & Social */}
          <div className="flex flex-col items-start md:items-end">
            {/* Navigation links */}
            <nav
              aria-label="Footer navigation"
              className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8 text-xs font-mono tracking-widest text-white/60 mb-6 md:mb-8"
            >
              <a
                href="#community"
                className="hover:text-[#B8F928] transition-colors uppercase py-0.5"
              >
                COMMUNITY
              </a>
              <a
                href="#space"
                className="hover:text-[#B8F928] transition-colors uppercase py-0.5"
              >
                SPACE
              </a>
              <a
                href="#about"
                className="hover:text-[#B8F928] transition-colors uppercase py-0.5"
              >
                ABOUT
              </a>
              <a
                href="#faq"
                className="hover:text-[#B8F928] transition-colors uppercase py-0.5"
              >
                FAQ
              </a>
              <a
                href="/privacy-policy"
                onClick={handlePrivacyClick}
                className="hover:text-[#B8F928] transition-colors uppercase py-0.5"
              >
                PRIVACY POLICY
              </a>
            </nav>

            {/* Instagram Icon */}
            <div className="flex items-center gap-3">
              <a
                href="https://www.instagram.com/x_oneoffice/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Follow X - One on Instagram"
                className="group p-2.5 rounded-full border border-white/10 bg-white/[0.02] text-white/50 hover:text-[#B8F928] hover:border-[#B8F928]/40 hover:bg-[#B8F928]/[0.05] transition-all duration-300 flex items-center justify-center focus:outline-none"
              >
                <Instagram className="w-4 h-4 transition-transform duration-300 group-hover:scale-110" />
              </a>
            </div>
          </div>
        </div>

        {/* FOOTER BOTTOM LINE: Divider & Credits */}
        <div className="border-t border-white/[0.06] pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-mono text-white/40">
          {/* LEFT: Copyright & Privacy Policy */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span>© 2026 X - One</span>
            <span className="text-white/20">/</span>
            <a
              href="/privacy-policy"
              onClick={handlePrivacyClick}
              className="hover:text-[#B8F928] text-white/50 transition-colors uppercase cursor-pointer"
            >
              Privacy Policy
            </a>
          </div>

          {/* RIGHT: Powered by Sorx Craft */}
          <div className="text-[11px] text-white/30 tracking-wider">
            Powered by Sorx Craft
          </div>
        </div>
      </div>
    </footer>
  );
};
