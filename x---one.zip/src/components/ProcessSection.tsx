import React, { useState, useEffect } from 'react';
import { PROCESS_STAGES } from '../data/community';
import { ArrowRight } from 'lucide-react';

export const ProcessSection: React.FC = () => {
  const [activeStageIndex, setActiveStageIndex] = useState(0);
  const activeStage = PROCESS_STAGES[activeStageIndex];

  // Subtle auto-cycle
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveStageIndex((prev) => (prev + 1) % PROCESS_STAGES.length);
    }, 5500);

    return () => clearInterval(timer);
  }, []);

  return (
    <section
      id="process"
      className="relative w-full py-28 sm:py-32 md:py-44 px-4 sm:px-6 md:px-12 overflow-hidden"
    >
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="max-w-2xl mb-12 sm:mb-16">
          <div className="flex items-center gap-3 mb-5 sm:mb-6">
            <div className="w-6 h-[1px] bg-[#B8F928]" />
            <span className="text-[10px] sm:text-[11px] font-mono tracking-[0.25em] text-[#B8F928] uppercase">
              WHAT HAPPENS HERE
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-light text-white tracking-tight leading-[1.15]">
            The Creative Sequence: <br />
            <span className="font-medium text-white">How ideas compound.</span>
          </h2>
        </div>

        {/* Minimalist Sequence Navigation Bar */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-3 mb-10 sm:mb-12 border-b border-white/[0.06] pb-4 sm:pb-5">
          {PROCESS_STAGES.map((stage, idx) => {
            const isActive = idx === activeStageIndex;
            return (
              <React.Fragment key={stage.id}>
                <button
                  onClick={() => setActiveStageIndex(idx)}
                  className={`group relative py-1.5 px-2.5 sm:px-4 rounded-full text-[11px] sm:text-xs font-mono tracking-wider transition-all duration-300 focus:outline-none ${
                    isActive
                      ? 'text-[#B8F928] bg-[#B8F928]/10 border border-[#B8F928]/30 shadow-[0_0_12px_rgba(184,249,40,0.12)]'
                      : 'text-white/40 hover:text-white/80 border border-transparent'
                  }`}
                >
                  <span className="text-[10px] text-white/30 mr-1 sm:mr-1.5">
                    0{idx + 1}
                  </span>
                  {stage.title}
                </button>
                {idx < PROCESS_STAGES.length - 1 && (
                  <span className="text-white/15 hidden md:inline select-none text-xs">/</span>
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Dynamic Sequence Display Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center rounded-2xl border border-white/[0.07] bg-white/[0.012] p-5 sm:p-8 md:p-12 overflow-hidden">
          {/* Left: Narrative Details */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-block px-2.5 py-1 rounded border border-[#B8F928]/20 bg-[#B8F928]/5 text-[10px] font-mono text-[#B8F928] uppercase tracking-widest">
              PHASE 0{activeStageIndex + 1} // {activeStage.action}
            </div>

            <h3 className="text-3xl sm:text-4xl font-light tracking-tight text-white">
              {activeStage.title}
            </h3>

            <p className="text-base sm:text-lg text-white/65 font-light leading-relaxed max-w-lg">
              {activeStage.description}
            </p>

            <div className="pt-2">
              <button
                onClick={() =>
                  setActiveStageIndex((prev) => (prev + 1) % PROCESS_STAGES.length)
                }
                className="inline-flex items-center gap-2 text-xs font-mono tracking-widest text-white/60 hover:text-[#B8F928] transition-colors focus:outline-none"
              >
                <span>NEXT PHASE</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#B8F928]" />
              </button>
            </div>
          </div>

          {/* Right: Architectural Geometric Canvas */}
          <div className="lg:col-span-6 aspect-video sm:aspect-square max-h-[340px] w-full rounded-xl border border-white/[0.06] bg-[#050505] p-6 relative flex items-center justify-center overflow-hidden">
            {/* Fine technical background grid */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

            {/* Stage-Specific Geometry */}
            {activeStage.geometryType === 'points' && (
              <svg className="w-full h-full relative z-10" viewBox="0 0 200 200">
                <g className="transition-all duration-700">
                  <circle cx="50" cy="80" r="2.5" fill="#B8F928" />
                  <circle cx="150" cy="70" r="2.5" fill="#B8F928" />
                  <circle cx="100" cy="140" r="2.5" fill="#B8F928" />
                  <circle cx="80" cy="60" r="1.5" fill="#fff" opacity="0.6" />
                  <circle cx="130" cy="120" r="1.5" fill="#fff" opacity="0.6" />

                  <line
                    x1="50"
                    y1="80"
                    x2="100"
                    y2="140"
                    stroke="#B8F928"
                    strokeWidth="0.8"
                    strokeDasharray="3,3"
                  />
                  <line
                    x1="150"
                    y1="70"
                    x2="100"
                    y2="140"
                    stroke="#B8F928"
                    strokeWidth="0.8"
                    strokeDasharray="3,3"
                  />
                  <line
                    x1="50"
                    y1="80"
                    x2="150"
                    y2="70"
                    stroke="rgba(255,255,255,0.15)"
                    strokeWidth="0.6"
                  />
                </g>
              </svg>
            )}

            {activeStage.geometryType === 'lines' && (
              <svg className="w-full h-full relative z-10" viewBox="0 0 200 200">
                <g className="transition-all duration-700">
                  <path
                    d="M 30 150 Q 80 40 170 80"
                    fill="none"
                    stroke="#B8F928"
                    strokeWidth="1.4"
                  />
                  <path
                    d="M 40 70 Q 120 170 160 50"
                    fill="none"
                    stroke="rgba(255,255,255,0.3)"
                    strokeWidth="0.9"
                  />
                  <path
                    d="M 50 120 C 80 80 120 80 150 120"
                    fill="none"
                    stroke="#B8F928"
                    strokeWidth="0.9"
                    strokeOpacity="0.6"
                  />
                  <circle cx="100" cy="100" r="3" fill="#B8F928" opacity="0.8" />
                </g>
              </svg>
            )}

            {activeStage.geometryType === 'grid' && (
              <svg className="w-full h-full relative z-10" viewBox="0 0 200 200">
                <g className="transition-all duration-700">
                  <rect
                    x="40"
                    y="40"
                    width="120"
                    height="120"
                    fill="none"
                    stroke="#B8F928"
                    strokeWidth="0.9"
                  />
                  <line
                    x1="40"
                    y1="80"
                    x2="160"
                    y2="80"
                    stroke="rgba(255,255,255,0.12)"
                    strokeWidth="0.6"
                  />
                  <line
                    x1="40"
                    y1="120"
                    x2="160"
                    y2="120"
                    stroke="rgba(255,255,255,0.12)"
                    strokeWidth="0.6"
                  />
                  <line
                    x1="80"
                    y1="40"
                    x2="80"
                    y2="160"
                    stroke="rgba(255,255,255,0.12)"
                    strokeWidth="0.6"
                  />
                  <line
                    x1="120"
                    y1="40"
                    x2="120"
                    y2="160"
                    stroke="rgba(255,255,255,0.12)"
                    strokeWidth="0.6"
                  />
                  <rect
                    x="80"
                    y="80"
                    width="40"
                    height="40"
                    fill="rgba(184,249,40,0.1)"
                    stroke="#B8F928"
                    strokeWidth="1"
                  />
                </g>
              </svg>
            )}

            {activeStage.geometryType === 'nodes' && (
              <svg className="w-full h-full relative z-10" viewBox="0 0 200 200">
                <g className="transition-all duration-700">
                  <circle cx="100" cy="100" r="8" fill="none" stroke="#B8F928" strokeWidth="1.2" />
                  <circle cx="100" cy="100" r="3" fill="#B8F928" />

                  {[
                    [50, 60],
                    [150, 60],
                    [160, 140],
                    [40, 130],
                    [100, 30],
                    [100, 170],
                  ].map(([nx, ny], i) => (
                    <React.Fragment key={i}>
                      <line
                        x1="100"
                        y1="100"
                        x2={nx}
                        y2={ny}
                        stroke="#B8F928"
                        strokeWidth="0.6"
                        strokeOpacity="0.5"
                      />
                      <circle cx={nx} cy={ny} r="2" fill="#fff" opacity="0.75" />
                    </React.Fragment>
                  ))}
                </g>
              </svg>
            )}

            {activeStage.geometryType === 'rings' && (
              <svg className="w-full h-full relative z-10" viewBox="0 0 200 200">
                <g className="transition-all duration-700">
                  <circle cx="100" cy="100" r="14" fill="none" stroke="#B8F928" strokeWidth="0.8" />
                  <circle cx="100" cy="100" r="32" fill="none" stroke="#B8F928" strokeWidth="1" opacity="0.7" />
                  <circle cx="100" cy="100" r="56" fill="none" stroke="#B8F928" strokeWidth="0.8" opacity="0.4" />
                  <circle cx="100" cy="100" r="80" fill="none" stroke="#B8F928" strokeWidth="0.6" opacity="0.2" />

                  <path
                    d="M 45 90 C 50 145 150 145 155 90"
                    fill="none"
                    stroke="#B8F928"
                    strokeWidth="1.2"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 65 95 C 70 135 130 135 135 95"
                    fill="none"
                    stroke="#B8F928"
                    strokeWidth="1.2"
                    strokeLinecap="round"
                    opacity="0.75"
                  />
                </g>
              </svg>
            )}

            {/* Micro Coordinates Badge */}
            <div className="absolute bottom-3 right-3 font-mono text-[9px] text-white/25 tracking-widest uppercase">
              X1-SYS // SEQ
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
