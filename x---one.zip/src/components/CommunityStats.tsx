import React, { useEffect, useState, useRef } from 'react';
import { COMMUNITY_STATS, CommunityStat } from '../data/community';

interface AnimatedCounterProps {
  stat: CommunityStat;
  inView: boolean;
}

const AnimatedNumberItem: React.FC<AnimatedCounterProps> = ({ stat, inView }) => {
  const [currentValue, setCurrentValue] = useState<number | string>(
    typeof stat.value === 'number' ? 0 : stat.value
  );

  useEffect(() => {
    if (!inView) return;

    if (typeof stat.value === 'number') {
      const target = stat.value;
      const duration = 1600;
      const steps = 30;
      const stepTime = duration / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += Math.ceil(target / steps);
        if (current >= target) {
          setCurrentValue(target);
          clearInterval(timer);
        } else {
          setCurrentValue(current);
        }
      }, stepTime);

      return () => clearInterval(timer);
    } else {
      setCurrentValue(stat.value);
    }
  }, [inView, stat.value]);

  return (
    <div className="flex flex-col items-center text-center select-none py-6 px-4">
      {/* Editorial Statistics — Large clean number, zero cards, zero boxes */}
      <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-light tracking-tight text-white flex items-baseline justify-center">
        <span className="font-light text-white">
          {currentValue}
        </span>
        {stat.suffix && (
          <span className="text-[#B8F928] font-mono text-3xl sm:text-4xl md:text-5xl ml-1 font-light">
            {stat.suffix}
          </span>
        )}
      </div>

      {/* Small Clean Monospaced Label with Generous Whitespace */}
      <div className="text-[11px] sm:text-xs font-mono tracking-[0.25em] text-white/40 uppercase mt-4">
        {stat.label}
      </div>
    </div>
  );
};

export const CommunityStats: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    if (typeof IntersectionObserver === 'undefined') {
      setInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry && entry.isIntersecting) {
          setInView(true);
        }
      },
      { threshold: 0.2 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full max-w-4xl mx-auto pt-16 sm:pt-24 pb-4 flex flex-col sm:flex-row items-center justify-around gap-12 sm:gap-6"
    >
      {COMMUNITY_STATS.map((stat) => (
        <AnimatedNumberItem key={stat.id} stat={stat} inView={inView} />
      ))}
    </div>
  );
};
