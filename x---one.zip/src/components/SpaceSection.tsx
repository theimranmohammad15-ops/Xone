import React from 'react';

export const SpaceSection: React.FC = () => {
  return (
    <section
      id="space"
      className="relative w-full py-28 sm:py-32 md:py-44 px-4 sm:px-6 md:px-12 overflow-hidden"
    >
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="max-w-2xl mb-12 sm:mb-16">
          <div className="flex items-center gap-3 mb-5 sm:mb-6">
            <div className="w-6 h-[1px] bg-[#B8F928]" />
            <span className="text-[10px] sm:text-[11px] font-mono tracking-[0.25em] text-[#B8F928] uppercase">
              PHYSICAL GROUND
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-light text-white tracking-tight leading-[1.15] mb-5 sm:mb-6">
            ONE SPACE. <br />
            <span className="font-medium text-white">MANY IDEAS.</span>
          </h2>

          <p className="text-sm sm:text-base md:text-lg text-white/60 font-light leading-relaxed">
            A small room can hold very big ideas. The physical foundation of the XOne Office in Nawada.
          </p>
        </div>

        {/* Minimal Architectural Visual Composition */}
        <div className="relative rounded-2xl border border-white/[0.07] bg-white/[0.012] p-5 sm:p-8 md:p-12 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Architectural Wireframe Blueprint */}
            <div className="lg:col-span-7 relative aspect-[4/3] w-full rounded-xl border border-white/[0.06] bg-[#050505] p-6 flex items-center justify-center overflow-hidden select-none">
              {/* Technical floor grid */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

              {/* Architectural Isometric Room Blueprint */}
              <svg
                viewBox="0 0 400 300"
                className="w-full h-full relative z-10"
                fill="none"
              >
                {/* Ground Plane Isometric Floor */}
                <polygon
                  points="200,80 340,160 200,240 60,160"
                  fill="rgba(255,255,255,0.01)"
                  stroke="rgba(255,255,255,0.12)"
                  strokeWidth="1"
                />

                {/* Back Left Wall */}
                <polygon
                  points="60,160 60,70 200,10 200,80"
                  fill="rgba(255,255,255,0.008)"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="0.8"
                />

                {/* Back Right Wall */}
                <polygon
                  points="200,80 200,10 340,90 340,160"
                  fill="rgba(255,255,255,0.015)"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="0.8"
                />

                {/* Collaborative Central Table */}
                <polygon
                  points="200,130 260,165 200,200 140,165"
                  fill="rgba(184,249,40,0.06)"
                  stroke="#B8F928"
                  strokeWidth="1"
                />
                {/* Table legs */}
                <line x1="200" y1="200" x2="200" y2="215" stroke="#B8F928" strokeWidth="0.8" strokeOpacity="0.8" />
                <line x1="140" y1="165" x2="140" y2="180" stroke="#B8F928" strokeWidth="0.8" strokeOpacity="0.8" />
                <line x1="260" y1="165" x2="260" y2="180" stroke="#B8F928" strokeWidth="0.8" strokeOpacity="0.8" />

                {/* Focal seats */}
                <circle cx="170" cy="148" r="2.5" fill="#B8F928" />
                <circle cx="230" cy="148" r="2.5" fill="#B8F928" />
                <circle cx="170" cy="182" r="2.5" fill="#fff" opacity="0.7" />
                <circle cx="230" cy="182" r="2.5" fill="#fff" opacity="0.7" />

                {/* Vertical upward projection */}
                <path
                  d="M 200,165 Q 200,100 200,50"
                  stroke="#B8F928"
                  strokeWidth="1.2"
                  strokeDasharray="3,3"
                />
                <circle cx="200" cy="50" r="3" fill="#B8F928" />

                {/* Architectural dimension callouts */}
                <line x1="45" y1="160" x2="45" y2="70" stroke="rgba(255,255,255,0.2)" strokeWidth="0.6" />
                <text x="35" y="118" fill="rgba(255,255,255,0.35)" fontSize="8" fontFamily="monospace">
                  H: 3.2m
                </text>
                <text x="210" y="270" fill="rgba(255,255,255,0.35)" fontSize="8" fontFamily="monospace">
                  BASE: COMPACT CREATIVE CORE
                </text>
              </svg>

              <div className="absolute top-4 left-4 font-mono text-[9px] text-white/35 tracking-widest uppercase">
                SPATIAL SPEC // V-01
              </div>
            </div>

            {/* Right: Thoughtful Architectural Philosophy */}
            <div className="lg:col-span-5 space-y-6">
              <div className="space-y-4">
                <h3 className="text-xl sm:text-2xl font-light text-white tracking-tight">
                  A small room with a big ecosystem.
                </h3>
                <p className="text-sm sm:text-base text-white/60 font-light leading-relaxed">
                  We don't believe in sterile acres of vacant cubicles or corporate formalities.
                  High-velocity breakthroughs happen when ambitious builders sit within earshot of each other.
                </p>
                <p className="text-sm sm:text-base text-white/60 font-light leading-relaxed">
                  An intimate founder office and creative space in Nawada, Bihar, where questions get answered in three seconds, feedback is unfiltered, and serendipity isn&apos;t an accident.
                </p>
              </div>

              {/* Spatial Attributes */}
              <div className="pt-4 border-t border-white/[0.06] grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div>
                  <div className="text-[10px] font-mono text-[#B8F928] uppercase tracking-wider mb-1">
                    Location
                  </div>
                  <div className="text-xs sm:text-sm font-mono text-white/80">
                    Nawada, Bihar
                  </div>
                </div>
                <div>
                  <div className="text-[10px] font-mono text-[#B8F928] uppercase tracking-wider mb-1">
                    Footprint
                  </div>
                  <div className="text-xs sm:text-sm font-mono text-white/80">
                    Dense & Friction-Free
                  </div>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <div className="text-[10px] font-mono text-[#B8F928] uppercase tracking-wider mb-1">
                    Community
                  </div>
                  <div className="text-xs sm:text-sm font-mono text-white/80">
                    Cross-Disciplinary
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
