import React from 'react';

interface XOneLogoProps {
  className?: string;
  size?: number | string;
  withGlow?: boolean;
  animated?: boolean;
}

/**
 * X - One Official Logo
 * Pure geometric vector rendering of multiple concentric curved forms
 * creating an open/upward radiating symbol in the signature X - One lime accent.
 */
export const XOneLogo: React.FC<XOneLogoProps> = ({
  className = 'w-10 h-10',
  size,
  withGlow = false,
  animated = false,
}) => {
  const style = size ? { width: size, height: size } : undefined;

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={style}
    >
      {withGlow && (
        <>
          {/* Soft outer atmospheric bloom */}
          <div
            className="absolute inset-[-35%] bg-[#B8F928] opacity-[0.07] blur-2xl pointer-events-none rounded-full"
            aria-hidden="true"
          />
          {/* Controlled close illumination */}
          <div
            className="absolute inset-[-12%] bg-[#B8F928] opacity-[0.14] blur-lg pointer-events-none rounded-full"
            aria-hidden="true"
          />
        </>
      )}
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`w-full h-full relative z-10 transition-transform duration-500 ease-out ${
          animated ? 'hover:scale-[1.03]' : ''
        }`}
      >
        <defs>
          {/* Signature lime accent gradient - physical light source feel */}
          <linearGradient id="xOneLimeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#A4EA1C" />
            <stop offset="50%" stopColor="#B8F928" />
            <stop offset="100%" stopColor="#CEFA69" />
          </linearGradient>

          <filter id="subtleAura" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow
              dx="0"
              dy="0"
              stdDeviation="2.2"
              floodColor="#B8F928"
              floodOpacity="0.26"
            />
          </filter>
        </defs>

        {/* Concentric curved forms creating an open/upward symbol */}
        {/* Arc 1 (Outermost open curve) */}
        <path
          d="M 16 34 C 20 74 80 74 84 34"
          stroke="url(#xOneLimeGrad)"
          strokeWidth="4"
          strokeLinecap="round"
          filter="url(#subtleAura)"
        />

        {/* Arc 2 (Middle-outer open curve) */}
        <path
          d="M 25 43 C 28 72 72 72 75 43"
          stroke="url(#xOneLimeGrad)"
          strokeWidth="4"
          strokeLinecap="round"
          strokeOpacity="0.9"
        />

        {/* Arc 3 (Middle-inner open curve) */}
        <path
          d="M 34 52 C 37 70 63 70 66 52"
          stroke="url(#xOneLimeGrad)"
          strokeWidth="3.8"
          strokeLinecap="round"
          strokeOpacity="0.82"
        />

        {/* Arc 4 (Innermost focal curve) */}
        <path
          d="M 43 60 C 45 68 55 68 57 60"
          stroke="url(#xOneLimeGrad)"
          strokeWidth="3.6"
          strokeLinecap="round"
        />

        {/* Central apex anchor dot at base of concentric geometry */}
        <circle
          cx="50"
          cy="74"
          r="1.6"
          fill="#B8F928"
          fillOpacity="0.75"
        />
      </svg>
    </div>
  );
};
