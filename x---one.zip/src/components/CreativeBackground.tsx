import React, { useEffect, useRef } from 'react';

interface CreativeBackgroundProps {
  interactiveStage?: string;
}

export const CreativeBackground: React.FC<CreativeBackgroundProps> = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    let isMobile = width < 768;
    let isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

    // Accessibility check: respect reduced motion
    const motionQuery = typeof window.matchMedia === 'function'
      ? window.matchMedia('(prefers-reduced-motion: reduce)')
      : null;
    let isReducedMotion = motionQuery?.matches ?? false;

    const handleMotionChange = (e: MediaQueryListEvent) => {
      isReducedMotion = e.matches;
      if (isReducedMotion) {
        drawFrame(0, 0);
      }
    };
    motionQuery?.addEventListener?.('change', handleMotionChange);

    // Particles for subtle alive atmospheric depth
    interface Particle {
      x: number;
      y: number;
      size: number;
      speedY: number;
      driftPhase: number;
      driftSpeed: number;
      alpha: number;
      isGreen: boolean;
    }

    const particleCount = isMobile ? 6 : 18;
    const particles: Particle[] = [];

    const initParticles = () => {
      particles.length = 0;
      const count = isMobile ? 6 : 18;
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * 0.8 + 0.6,
          speedY: Math.random() * 0.015 + 0.008,
          driftPhase: Math.random() * Math.PI * 2,
          driftSpeed: Math.random() * 0.0015 + 0.0008,
          alpha: Math.random() * 0.09 + 0.04,
          isGreen: Math.random() > 0.75,
        });
      }
    };

    initParticles();

    // Mouse tracking for desktop atmospheric response (smooth easing)
    const mouse = {
      x: width * 0.5,
      y: height * 0.4,
      targetX: width * 0.5,
      targetY: height * 0.4,
      normalizedX: 0,
      normalizedY: 0,
    };

    // Scroll state with multi-layer parallax damping
    const scroll = {
      current: 0,
      target: 0,
      velocity: 0,
    };

    // Responsive Canvas Resolution
    const resizeCanvas = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      isMobile = width < 768;
      isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    // Event Listeners
    const handleResize = () => {
      resizeCanvas();
      if (isReducedMotion) {
        drawFrame(0, 0);
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isTouch) return;
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
      mouse.normalizedX = (e.clientX / width - 0.5) * 2;
      mouse.normalizedY = (e.clientY / height - 0.5) * 2;
    };

    const handleScroll = () => {
      const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      scroll.target = window.scrollY / maxScroll;
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });

    resizeCanvas();

    // Render Frame Function
    let animationFrameId: number;
    let lastTime = performance.now();
    let totalTime = 0;

    const drawFrame = (_time: number, dt: number) => {
      if (!ctx || width <= 10 || height <= 10) return;

      try {
        const s = scroll.current; // 0 (Hero) to 1 (Footer)

      // Section environmental dynamics
      const isCommunity = Math.max(0, 1 - Math.abs(s - 0.42) * 3.5);
      const isTech = Math.max(0, 1 - Math.abs(s - 0.72) * 3.5);

      // Slow, observable atmospheric cycles (~22-30s)
      const t = totalTime * 0.00028;
      const driftX = Math.sin(t * 1.0) * (isMobile ? 28 : 58);
      const driftY = Math.cos(t * 0.85) * (isMobile ? 22 : 46);
      const pulseA = Math.sin(t * 1.5) * 0.12;
      const pulseB = Math.cos(t * 1.2) * 0.14;

      // Mouse influence on desktop: clearly observable but dignified studio reaction
      const mouseShiftX = mouse.normalizedX * (isMobile ? 0 : 42);
      const mouseShiftY = mouse.normalizedY * (isMobile ? 0 : 34);

      // ==========================================
      // 1. BASE LAYER: DARK GRAPHITE FOUNDATION
      // ==========================================
      // Diagonal gradient using specified rich graphite palette
      const baseGrad = ctx.createLinearGradient(0, 0, width, height);
      baseGrad.addColorStop(0, '#080909');
      baseGrad.addColorStop(0.48, '#0D0F0F');
      baseGrad.addColorStop(1, '#121515');
      ctx.fillStyle = baseGrad;
      ctx.fillRect(0, 0, width, height);

      // Secondary deep charcoal studio fill for architectural contrast
      const studioBase = ctx.createRadialGradient(
        width * 0.5 + driftX * 0.3,
        height * 0.45 + (s - 0.5) * height * 0.2,
        width * 0.1,
        width * 0.5,
        height * 0.5,
        Math.max(width, height) * 0.9
      );
      studioBase.addColorStop(0, 'rgba(32, 38, 40, 0.42)');
      studioBase.addColorStop(0.5, 'rgba(18, 22, 23, 0.25)');
      studioBase.addColorStop(1, 'rgba(8, 9, 9, 0)');
      ctx.fillStyle = studioBase;
      ctx.fillRect(0, 0, width, height);

      // ==========================================
      // 2. MIDDLE LAYER: LARGE SOFT BLURRED ATMOSPHERIC LIGHTS
      // ==========================================
      // LIGHT FIELD 1: Primary Soft Platinum/Gray Studio Light
      // Enhanced visibility (2.5x), smooth multi-stop falloff, observable parallax
      const light1X =
        width * (0.54 + Math.sin(s * Math.PI * 1.4) * 0.16) +
        driftX +
        mouseShiftX;
      const light1Y =
        height * (0.32 + s * 0.38) +
        driftY +
        mouseShiftY;
      const light1Radius = (isMobile ? 420 : 720) * (1 + pulseA * 0.16);

      const grad1 = ctx.createRadialGradient(
        light1X,
        light1Y,
        0,
        light1X,
        light1Y,
        light1Radius
      );
      const alpha1 = isMobile ? 0.28 : 0.36;
      grad1.addColorStop(0, `rgba(235, 242, 250, ${alpha1})`);
      grad1.addColorStop(0.24, `rgba(180, 195, 210, ${alpha1 * 0.68})`);
      grad1.addColorStop(0.52, `rgba(95, 110, 125, ${alpha1 * 0.32})`);
      grad1.addColorStop(0.82, `rgba(32, 38, 44, ${alpha1 * 0.08})`);
      grad1.addColorStop(1, 'rgba(8, 9, 9, 0)');

      ctx.fillStyle = grad1;
      ctx.fillRect(0, 0, width, height);

      // LIGHT FIELD 2: Secondary Soft Silver/Graphite Pool (Lower Left & Counter-Balance)
      const light2X =
        width * (0.24 - s * 0.12) -
        driftX * 0.75 -
        mouseShiftX * 0.6;
      const light2Y =
        height * (0.72 - s * 0.2) -
        driftY * 0.75 -
        mouseShiftY * 0.6;
      const light2Radius = (isMobile ? 360 : 580) * (1 + pulseB * 0.15);

      const grad2 = ctx.createRadialGradient(
        light2X,
        light2Y,
        0,
        light2X,
        light2Y,
        light2Radius
      );
      const alpha2 = isMobile ? 0.2 : 0.26;
      grad2.addColorStop(0, `rgba(205, 218, 228, ${alpha2})`);
      grad2.addColorStop(0.3, `rgba(135, 150, 164, ${alpha2 * 0.58})`);
      grad2.addColorStop(0.65, `rgba(50, 60, 68, ${alpha2 * 0.22})`);
      grad2.addColorStop(1, 'rgba(8, 9, 9, 0)');

      ctx.fillStyle = grad2;
      ctx.fillRect(0, 0, width, height);

      // LIGHT FIELD 3: DEEP SOPHISTICATED GREEN AMBIENT GLOW
      // Distinctly visible without being neon — deep emerald, pine, with ambient lime core
      const greenX =
        width * (0.42 - Math.sin(s * Math.PI * 1.2) * 0.18) -
        driftX * 0.9 +
        mouseShiftX * 0.8;
      const greenY =
        height * (0.44 + Math.cos(s * Math.PI * 1.1) * 0.22) -
        driftY * 0.9 +
        mouseShiftY * 0.8;
      const greenRadius = (isMobile ? 380 : 660) * (1 - pulseA * 0.12);

      const greenGrad = ctx.createRadialGradient(
        greenX,
        greenY,
        0,
        greenX,
        greenY,
        greenRadius
      );
      // Increased visibility: palpable deep green atmosphere
      const greenAlpha = (0.16 + isCommunity * 0.08) * (isMobile ? 0.8 : 1.0);
      greenGrad.addColorStop(0, `rgba(184, 249, 40, ${greenAlpha * 0.85})`);
      greenGrad.addColorStop(0.22, `rgba(64, 130, 85, ${greenAlpha * 0.95})`);
      greenGrad.addColorStop(0.5, `rgba(26, 68, 44, ${greenAlpha * 0.65})`);
      greenGrad.addColorStop(0.78, `rgba(12, 38, 24, ${greenAlpha * 0.25})`);
      greenGrad.addColorStop(1, 'rgba(8, 9, 9, 0)');

      ctx.fillStyle = greenGrad;
      ctx.fillRect(0, 0, width, height);

      // ==========================================
      // 3. FRONT ATMOSPHERE: REFINED ATMOSPHERIC LIGHT PATH
      // ==========================================
      // A singular, ultra-delicate, slow cinematic atmospheric light path
      // Gently traverses the environment like soft light diffusing through air
      const pathTime = t * 0.14; // Extremely slow, tranquil pace
      const scrollParallaxY = s * (isMobile ? 40 : 85);
      const baseY = height * 0.44 + Math.sin(pathTime) * (isMobile ? 14 : 26) - scrollParallaxY;

      // Gentle organic curve across the canvas
      const cp1x = width * (0.3 + Math.cos(pathTime * 0.6) * 0.06);
      const cp1y = baseY + Math.sin(pathTime * 0.8) * (isMobile ? 16 : 30);
      const cp2x = width * (0.7 + Math.sin(pathTime * 0.5) * 0.06);
      const cp2y = baseY - Math.cos(pathTime * 0.7) * (isMobile ? 15 : 28);
      const endY = baseY + Math.sin(pathTime * 0.9) * (isMobile ? 10 : 20);

      // Subtle gradient in brightness along the path: soft platinum to muted silver with faint mineral luminescence
      const lineGrad = ctx.createLinearGradient(0, baseY, width, endY);
      const baseAlpha = isMobile ? 0.045 : 0.07;
      lineGrad.addColorStop(0, 'rgba(215, 228, 238, 0)');
      lineGrad.addColorStop(0.2, `rgba(220, 235, 245, ${baseAlpha * 0.45})`);
      lineGrad.addColorStop(0.5, `rgba(235, 245, 252, ${baseAlpha * 1.05})`);
      lineGrad.addColorStop(0.75, `rgba(165, 222, 185, ${baseAlpha * 0.75})`);
      lineGrad.addColorStop(0.92, `rgba(184, 249, 40, ${baseAlpha * 0.25})`);
      lineGrad.addColorStop(1, 'rgba(184, 249, 40, 0)');

      ctx.save();
      // 1. Soft blurred atmospheric aura
      ctx.strokeStyle = lineGrad;
      ctx.lineWidth = isMobile ? 3.5 : 5.5;
      ctx.filter = 'blur(5px)';
      ctx.beginPath();
      ctx.moveTo(-40, baseY);
      ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, width + 40, endY);
      ctx.stroke();

      // 2. Thinner, pristine central filament (gentle light path)
      ctx.lineWidth = isMobile ? 0.75 : 0.95;
      ctx.filter = 'blur(0.6px)';
      ctx.beginPath();
      ctx.moveTo(-40, baseY);
      ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, width + 40, endY);
      ctx.stroke();
      ctx.restore();

      // ==========================================
      // 4. ATMOSPHERIC PARTICLES: SUBTLE FLOATING LIGHT MOTES
      // ==========================================
      // Drifts gently upward and sideways, barely noticeable, adding alive depth
      if (!isReducedMotion) {
        for (let i = 0; i < particles.length; i++) {
          const p = particles[i];
          p.y -= p.speedY * dt;
          p.driftPhase += p.driftSpeed * dt;
          if (p.y < -10) {
            p.y = height + 10;
            p.x = Math.random() * width;
          }

          const currentX = p.x + Math.sin(p.driftPhase) * (isMobile ? 6 : 14);
          ctx.beginPath();
          ctx.arc(currentX, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = p.isGreen
            ? `rgba(184, 249, 40, ${p.alpha * 0.75})`
            : `rgba(235, 242, 250, ${p.alpha})`;
          ctx.fill();
        }
      }

      // ==========================================
      // 4. TECHNICAL LAYER: FAINT REFINED GRID & COORDINATE DETAILS
      // ==========================================
      // Observable when inspecting the background, spaced comfortably, never competing with text
      const gridSize = isMobile ? 64 : 84;
      const gridAlpha = (isMobile ? 0.042 : 0.058) + (isTech ? 0.02 : 0);

      ctx.strokeStyle = `rgba(220, 230, 242, ${gridAlpha})`;
      ctx.lineWidth = 1;
      ctx.beginPath();

      // Parallax scroll on grid
      const gridShiftY = (s * 110) % gridSize;
      const gridShiftX = (mouseShiftX * 0.25) % gridSize;

      for (let x = -gridSize + gridShiftX; x <= width + gridSize; x += gridSize) {
        ctx.moveTo(Math.floor(x) + 0.5, 0);
        ctx.lineTo(Math.floor(x) + 0.5, height);
      }

      for (let y = -gridSize + gridShiftY; y <= height + gridSize; y += gridSize) {
        ctx.moveTo(0, Math.floor(y) + 0.5);
        ctx.lineTo(width, Math.floor(y) + 0.5);
      }

      ctx.stroke();

      // Subtle architectural cross-ticks at grid intersections (every 3 units)
      const tickStep = gridSize * (isMobile ? 4 : 3);
      ctx.strokeStyle = `rgba(240, 248, 255, ${gridAlpha * 1.9})`;
      ctx.lineWidth = 1.2;
      ctx.beginPath();

      for (let x = gridShiftX; x <= width; x += tickStep) {
        for (let y = gridShiftY; y <= height; y += tickStep) {
          const px = Math.floor(x);
          const py = Math.floor(y);
          // Small precise cross-tick '+'
          ctx.moveTo(px - 3, py);
          ctx.lineTo(px + 3, py);
          ctx.moveTo(px, py - 3);
          ctx.lineTo(px, py + 3);
        }
      }
      ctx.stroke();
    } catch (err) {
      console.error('CreativeBackground draw error:', err);
    }
  };

    // Main Smooth Animation Loop
    const loop = (time: number) => {
      const dt = Math.min(time - lastTime, 40);
      lastTime = time;
      totalTime += dt;

      // Smooth mouse interpolation
      mouse.x += (mouse.targetX - mouse.x) * 0.045;
      mouse.y += (mouse.targetY - mouse.y) * 0.045;

      // Smooth scroll damping
      const prevScroll = scroll.current;
      scroll.current += (scroll.target - scroll.current) * 0.055;
      scroll.velocity = scroll.current - prevScroll;

      drawFrame(time, dt);

      if (!isReducedMotion) {
        animationFrameId = requestAnimationFrame(loop);
      }
    };

    if (isReducedMotion) {
      drawFrame(0, 0);
    } else {
      animationFrameId = requestAnimationFrame(loop);
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      motionQuery?.removeEventListener?.('change', handleMotionChange);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#080909]"
      aria-hidden="true"
    >
      {/* Dynamic Multi-Layer Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full block"
        style={{ pointerEvents: 'none' }}
      />

      {/* LAYER 5: Observable Cinematic Tactile Grain Texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.055] mix-blend-overlay"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.78' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
        }}
        aria-hidden="true"
      />

      {/* Atmospheric Framing Vignette (Gentle Falloff ensuring text contrast) */}
      <div
        className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(8,9,9,0.35)_82%,rgba(8,9,9,0.75)_100%)] pointer-events-none"
        aria-hidden="true"
      />

      {/* Horizon Ambient Soft Edge Transition */}
      <div
        className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#080909] to-transparent pointer-events-none"
        aria-hidden="true"
      />
    </div>
  );
};
