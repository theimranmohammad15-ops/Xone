import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

const FAQS: FaqItem[] = [
  {
    id: 'what-is-xone',
    question: 'What is XOne and what does X-One Office provide?',
    answer:
      'XOne (also referred to as X-One or X One Office) is an office, founder community, and AI digital innovation ecosystem in Nawada, Bihar. It provides a focused environment for founders, creators, developers, and entrepreneurs to connect, collaborate, and scale their ideas.',
  },
  {
    id: 'who-can-join',
    question: 'Who can join the XOne founder community?',
    answer:
      'The XOne founder community is open to early-stage founders, indie creators, software developers, students, small agencies, and SaaS builders across Bihar and beyond who want to share frameworks, strategy, and collaborate on real technology.',
  },
  {
    id: 'what-happens-ai-lab',
    question: 'What happens at the XOne AI Lab?',
    answer:
      'XOne AI Lab is our internal research and experimentation wing dedicated to applied artificial intelligence, rapid prototyping, and developing practical AI tools for founders and automated startup workflows.',
  },
  {
    id: 'what-is-xone-bot',
    question: 'What is XOne.bot and how does it relate to XOne?',
    answer:
      'XOne.bot is an AI-powered digital office platform currently in active development by XOne. While XOne represents the broader office and founder ecosystem, XOne.bot is designed to assemble a specialized AI team for founders (including an AI co-founder, developer, designer, and marketer) to coordinate work from simple commands.',
  },
  {
    id: 'where-located',
    question: 'Where is the XOne office located in Nawada, Bihar?',
    answer:
      'XOne is located in Nawada, Bihar, India, offering an intimate founder office and creative workspace designed for deep focus and regional startup networking.',
  },
  {
    id: 'how-to-connect',
    question: 'How can someone connect with the XOne community?',
    answer:
      'You can connect directly with the XOne team and community through the official XOne website, join our official WhatsApp community channel, follow us on Instagram @x_oneoffice, or reach out to community members in Nawada.',
  },
];

export const FaqSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>(FAQS[0].id);

  const toggleItem = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section
      id="faq"
      className="relative w-full py-28 sm:py-32 md:py-44 px-4 sm:px-6 md:px-12 overflow-hidden"
    >
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="max-w-2xl mb-12 sm:mb-16">
          <div className="flex items-center gap-3 mb-5 sm:mb-6">
            <div className="w-6 h-[1px] bg-[#B8F928]" />
            <span className="text-[10px] sm:text-[11px] font-mono tracking-[0.25em] text-[#B8F928] uppercase">
              FREQUENTLY ASKED QUESTIONS
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-light text-white tracking-tight leading-[1.15] mb-5 sm:mb-6">
            Understanding XOne. <br />
            <span className="font-medium text-white">Clear answers.</span>
          </h2>

          <p className="text-sm sm:text-base md:text-lg text-white/60 font-light leading-relaxed">
            Essential details about our office, founder community, AI Lab research, and XOne.bot.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-3.5">
          {FAQS.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className="rounded-xl border border-white/[0.07] bg-white/[0.015] hover:border-white/[0.14] transition-all duration-300 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggleItem(faq.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between text-left p-5 sm:p-6 focus:outline-none group"
                >
                  <h3 className="text-sm sm:text-base md:text-lg font-light text-white/90 group-hover:text-white transition-colors pr-4">
                    {faq.question}
                  </h3>
                  <div
                    className={`w-6 h-6 rounded-full border border-white/10 flex items-center justify-center shrink-0 transition-all duration-300 ${
                      isOpen
                        ? 'border-[#B8F928]/40 bg-[#B8F928]/10 text-[#B8F928] rotate-180'
                        : 'text-white/40 group-hover:text-white group-hover:border-white/20'
                    }`}
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </div>
                </button>

                <div
                  className={`grid transition-all duration-300 ease-in-out ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 sm:px-6 sm:pb-6 text-xs sm:text-sm md:text-base text-white/65 font-light leading-relaxed border-t border-white/[0.04] pt-4">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
