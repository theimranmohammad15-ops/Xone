import React from 'react';
import { CommunityStats } from './CommunityStats';
import { CommunityCoreSphere } from './CommunityCoreSphere';

export const CommunitySection: React.FC = () => {
  return (
    <section
      id="community"
      className="relative w-full py-28 sm:py-32 md:py-44 px-4 sm:px-6 md:px-12 overflow-hidden"
    >
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 md:mb-16">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-6 h-[1px] bg-[#B8F928]" />
            <span className="text-[11px] font-mono tracking-[0.25em] text-[#B8F928] uppercase">
              THE X - ONE COMMUNITY
            </span>
            <div className="w-6 h-[1px] bg-[#B8F928]" />
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light text-white tracking-tight leading-[1.12] mb-6">
            Build around people <br />
            <span className="font-medium text-white">who build.</span>
          </h2>

          <p className="text-base sm:text-lg text-white/60 font-light leading-relaxed max-w-xl mx-auto">
            A founder community and startup network in Nawada and Bihar. Connect with creators, developers, and entrepreneurs building defensible ventures.
          </p>
        </div>

        {/* X-One Community Core — Spatial Transparent Glass Constellation */}
        <div className="relative w-full max-w-3xl mx-auto mb-20 md:mb-28 select-none">
          {/* Subtle local atmospheric glow behind the sphere blending seamlessly into global background */}
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] sm:w-[480px] h-[340px] sm:h-[480px] bg-[#B8F928]/[0.035] blur-[100px] rounded-full pointer-events-none"
            aria-hidden="true"
          />

          {/* DESKTOP & TABLET: Spatial Constellation Layout */}
          <div className="hidden sm:block relative w-full h-[540px] md:h-[580px]">
            {/* Subtle Connection Lines SVG Layer (Connecting People -> Core) */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none z-10"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              <defs>
                <linearGradient id="lineGradTop" x1="50%" y1="0%" x2="50%" y2="100%">
                  <stop offset="0%" stopColor="#B8F928" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#B8F928" stopOpacity="0.08" />
                </linearGradient>
                <linearGradient id="lineGradBottom" x1="50%" y1="100%" x2="50%" y2="0%">
                  <stop offset="0%" stopColor="#B8F928" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#B8F928" stopOpacity="0.08" />
                </linearGradient>
                <linearGradient id="lineGradLeft" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" stopOpacity="0.3" />
                  <stop offset="60%" stopColor="#B8F928" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#B8F928" stopOpacity="0.06" />
                </linearGradient>
                <linearGradient id="lineGradRight" x1="100%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" stopOpacity="0.3" />
                  <stop offset="60%" stopColor="#B8F928" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#B8F928" stopOpacity="0.06" />
                </linearGradient>
              </defs>

              {/* Top: Founders -> Top Rim of Core */}
              <line
                x1="50"
                y1="11"
                x2="50"
                y2="26"
                stroke="url(#lineGradTop)"
                strokeWidth="0.35"
                strokeDasharray="1.5, 1.5"
              />
              <circle cx="50" cy="26" r="0.6" fill="#B8F928" fillOpacity="0.75" />

              {/* Upper Left: Creators -> Upper-Left Rim of Core */}
              <path
                d="M 27 28 C 36 29, 39 37, 42 41"
                fill="none"
                stroke="url(#lineGradLeft)"
                strokeWidth="0.35"
                strokeDasharray="1.5, 1.5"
              />
              <circle cx="42" cy="41" r="0.6" fill="#B8F928" fillOpacity="0.75" />

              {/* Upper Right: Developers -> Upper-Right Rim of Core */}
              <path
                d="M 73 28 C 64 29, 61 37, 58 41"
                fill="none"
                stroke="url(#lineGradRight)"
                strokeWidth="0.35"
                strokeDasharray="1.5, 1.5"
              />
              <circle cx="58" cy="41" r="0.6" fill="#B8F928" fillOpacity="0.75" />

              {/* Lower Left: Builders -> Lower-Left Rim of Core */}
              <path
                d="M 28 72 C 37 71, 39 63, 42 59"
                fill="none"
                stroke="url(#lineGradLeft)"
                strokeWidth="0.35"
                strokeDasharray="1.5, 1.5"
              />
              <circle cx="42" cy="59" r="0.6" fill="#B8F928" fillOpacity="0.75" />

              {/* Lower Right: Agencies -> Lower-Right Rim of Core */}
              <path
                d="M 72 72 C 63 71, 61 63, 58 59"
                fill="none"
                stroke="url(#lineGradRight)"
                strokeWidth="0.35"
                strokeDasharray="1.5, 1.5"
              />
              <circle cx="58" cy="59" r="0.6" fill="#B8F928" fillOpacity="0.75" />

              {/* Bottom: Students -> Bottom Rim of Core */}
              <line
                x1="50"
                y1="89"
                x2="50"
                y2="74"
                stroke="url(#lineGradBottom)"
                strokeWidth="0.35"
                strokeDasharray="1.5, 1.5"
              />
              <circle cx="50" cy="74" r="0.6" fill="#B8F928" fillOpacity="0.75" />
            </svg>

            {/* Central Floating Transparent Core Sphere */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-20">
              {/* Subtle top indicator */}
              <div className="text-[9px] font-mono tracking-[0.3em] text-[#B8F928]/85 uppercase mb-1 text-center pointer-events-auto">
                [ X - ONE COMMUNITY CORE ]
              </div>

              {/* 3D Transparent Glass Sphere Canvas */}
              <CommunityCoreSphere className="w-full max-w-[380px] md:max-w-[420px]" />
            </div>

            {/* Label 1: FOUNDERS (Top Center) */}
            <div className="absolute top-[4%] left-1/2 -translate-x-1/2 z-30">
              <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/75 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-[#B8F928]/40 hover:bg-[#121618]/90 group">
                <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-white/75 group-hover:text-white uppercase">
                  FOUNDERS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)] group-hover:scale-125 transition-transform" />
              </div>
            </div>

            {/* Label 2: CREATORS (Upper Left) */}
            <div className="absolute top-[25%] left-[8%] md:left-[11%] z-30">
              <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/75 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-[#B8F928]/40 hover:bg-[#121618]/90 group">
                <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-white/75 group-hover:text-white uppercase">
                  CREATORS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)] group-hover:scale-125 transition-transform" />
              </div>
            </div>

            {/* Label 3: DEVELOPERS (Upper Right) */}
            <div className="absolute top-[25%] right-[8%] md:right-[11%] z-30">
              <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/75 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-[#B8F928]/40 hover:bg-[#121618]/90 group">
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)] group-hover:scale-125 transition-transform" />
                <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-white/75 group-hover:text-white uppercase">
                  DEVELOPERS
                </span>
              </div>
            </div>

            {/* Label 4: BUILDERS (Lower Left) */}
            <div className="absolute top-[69%] left-[9%] md:left-[12%] z-30">
              <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/75 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-[#B8F928]/40 hover:bg-[#121618]/90 group">
                <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-white/75 group-hover:text-white uppercase">
                  BUILDERS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)] group-hover:scale-125 transition-transform" />
              </div>
            </div>

            {/* Label 5: AGENCIES (Lower Right) */}
            <div className="absolute top-[69%] right-[9%] md:right-[12%] z-30">
              <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/75 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-[#B8F928]/40 hover:bg-[#121618]/90 group">
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)] group-hover:scale-125 transition-transform" />
                <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-white/75 group-hover:text-white uppercase">
                  AGENCIES
                </span>
              </div>
            </div>

            {/* Label 6: STUDENTS (Bottom Center) */}
            <div className="absolute bottom-[4%] left-1/2 -translate-x-1/2 z-30">
              <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/75 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all duration-300 hover:border-[#B8F928]/40 hover:bg-[#121618]/90 group">
                <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-white/75 group-hover:text-white uppercase">
                  STUDENTS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)] group-hover:scale-125 transition-transform" />
              </div>
            </div>
          </div>

          {/* MOBILE: Clean Stacked Spatial Composition (No overflow) */}
          <div className="block sm:hidden relative w-full flex flex-col items-center">
            {/* Top Label: FOUNDERS */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/80 backdrop-blur-md mb-2 shadow-sm">
              <span className="text-[10px] font-mono tracking-widest text-white/80 uppercase">
                FOUNDERS
              </span>
              <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)]" />
            </div>

            {/* Subtle top indicator */}
            <div className="text-[9px] font-mono tracking-[0.28em] text-[#B8F928]/85 uppercase my-1 text-center">
              [ X - ONE COMMUNITY CORE ]
            </div>

            {/* Central Transparent Sphere */}
            <CommunityCoreSphere className="w-full max-w-[270px] min-[380px]:max-w-[310px]" />

            {/* Mid & Lower Labels Grid */}
            <div className="flex flex-wrap items-center justify-center gap-2 max-w-xs mx-auto mt-2">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/80 backdrop-blur-md">
                <span className="text-[10px] font-mono tracking-widest text-white/80 uppercase">
                  CREATORS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)]" />
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/80 backdrop-blur-md">
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)]" />
                <span className="text-[10px] font-mono tracking-widest text-white/80 uppercase">
                  DEVELOPERS
                </span>
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/80 backdrop-blur-md">
                <span className="text-[10px] font-mono tracking-widest text-white/80 uppercase">
                  BUILDERS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)]" />
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/80 backdrop-blur-md">
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)]" />
                <span className="text-[10px] font-mono tracking-widest text-white/80 uppercase">
                  AGENCIES
                </span>
              </div>

              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.09] bg-[#0c0f10]/80 backdrop-blur-md">
                <span className="text-[10px] font-mono tracking-widest text-white/80 uppercase">
                  STUDENTS
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#B8F928] shadow-[0_0_6px_rgba(184,249,40,0.8)]" />
              </div>
            </div>
          </div>
        </div>

        {/* Editorial Community Statistics */}
        <CommunityStats />
      </div>
    </section>
  );
};
