import React, { useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { XOneLogo } from './XOneLogo';

interface PrivacyPolicyProps {
  onBack: () => void;
}

export const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onBack }) => {
  // Ensure we start at top of page when mounted
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <article className="relative min-h-screen py-20 sm:py-32 px-4 sm:px-8 md:px-12 z-20">
      <div className="max-w-3xl mx-auto">
        {/* Top Back Navigation */}
        <div className="mb-10 sm:mb-12">
          <button
            onClick={onBack}
            className="group inline-flex items-center gap-2.5 text-xs font-mono tracking-widest text-white/60 hover:text-[#B8F928] transition-colors focus:outline-none"
            aria-label="Return to X-One main site"
          >
            <ArrowLeft className="w-3.5 h-3.5 transition-transform duration-200 group-hover:-translate-x-1" />
            <span>← Back to X-One</span>
          </button>
        </div>

        {/* Header Block */}
        <header className="border-b border-white/[0.08] pb-8 mb-12">
          <div className="flex items-center gap-3 mb-4">
            <XOneLogo size={22} withGlow={false} />
            <span className="text-xs font-mono tracking-[0.25em] text-[#B8F928] uppercase">
              LEGAL & TRANSPARENCY
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-light text-white tracking-tight leading-tight mb-3">
            Privacy Policy
          </h1>

          <div className="text-xs font-mono text-white/40 tracking-wider">
            Last Updated: September 24, 2026
          </div>
        </header>

        {/* Content Body */}
        <div className="space-y-10 text-white/75 font-light text-sm sm:text-base leading-relaxed">
          {/* 1. Introduction */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              1. Introduction
            </h2>
            <p className="text-white/70">
              Welcome to X - One. We are committed to maintaining a transparent, respectful, and secure digital environment for everyone exploring our creative community, AI Lab research, and digital office initiatives. This Privacy Policy describes how information is handled when you visit and interact with the X - One website.
            </p>
          </section>

          {/* 2. Information We Collect */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              2. Information We Collect
            </h2>
            <p className="text-white/70 mb-3">
              This website serves primarily as an informational presentation of the X - One ecosystem. In its current implementation:
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-white/65 pl-1">
              <li>
                <strong className="text-white/80 font-normal">No Account Profiles:</strong> We do not offer on-site user registrations, passwords, or stored user profiles on this website.
              </li>
              <li>
                <strong className="text-white/80 font-normal">No Financial Processing:</strong> We do not request, process, or store credit cards, bank credentials, or payment transactions on this site.
              </li>
              <li>
                <strong className="text-white/80 font-normal">No Passive Personal Tracking:</strong> We do not deploy behavioral surveillance scripts, ad retargeting pixels, or intrusive personal identity collectors.
              </li>
              <li>
                <strong className="text-white/80 font-normal">Direct Communications:</strong> If you voluntarily choose to contact us or join our community via external platforms (such as WhatsApp or Instagram), any information you choose to share is provided directly by you through those external services.
              </li>
            </ul>
          </section>

          {/* 3. How We Use Information */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              3. How We Use Information
            </h2>
            <p className="text-white/70">
              Because we do not collect personal data records through this website, we do not sell, rent, monetize, or profile your personal data. Any external inquiries received via our direct communication channels are used solely to answer your questions, facilitate community participation, and discuss collaborative projects.
            </p>
          </section>

          {/* 4. Cookies and Similar Technologies */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              4. Cookies and Similar Technologies
            </h2>
            <p className="text-white/70">
              This website does not deploy persistent advertising cookies, cross-site trackers, or third-party profiling cookies. Standard client-side session mechanisms inherent to modern web browsers (such as transient local memory) are used strictly to render user interface layouts, animations, and preserve your fluid navigation.
            </p>
          </section>

          {/* 5. Third-Party Services */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              5. Third-Party Services
            </h2>
            <p className="text-white/70">
              Our website provides external links to third-party services, including community channels (WhatsApp) and social media (Instagram). When you follow these external links, you leave the X - One website. We encourage you to review the privacy policies of those respective third-party platforms, as their data handling is governed by their independent terms.
            </p>
          </section>

          {/* 6. Data Security */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              6. Data Security
            </h2>
            <p className="text-white/70">
              We employ standard transport layer security (HTTPS encryption) across all web requests to safeguard the integrity and confidentiality of content delivered between your browser and our hosting infrastructure.
            </p>
          </section>

          {/* 7. Data Retention */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              7. Data Retention
            </h2>
            <p className="text-white/70">
              Because this website does not capture or store personal records in a database, we do not maintain personal data retention periods on this web application.
            </p>
          </section>

          {/* 8. Your Privacy Choices */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              8. Your Privacy Choices
            </h2>
            <p className="text-white/70">
              You have the right to navigate our website without disclosing any personally identifiable information. You may also configure your browser to reject cookies or block external network requests at your discretion without losing access to our core informational content.
            </p>
          </section>

          {/* 9. Children's Privacy */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              9. Children's Privacy
            </h2>
            <p className="text-white/70">
              Our website is intended for founders, creators, developers, students, and professionals interested in creative technology. We do not knowingly solicit or collect personal information from children under the age of 13 (or applicable local age limits).
            </p>
          </section>

          {/* 10. Changes to This Privacy Policy */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              10. Changes to This Privacy Policy
            </h2>
            <p className="text-white/70">
              As X - One evolves — including the active development of X - One.bot and research in our AI Lab — we may update this Privacy Policy to accurately describe any new capabilities or services. When modifications occur, the "Last Updated" date at the top of this document will be updated accordingly.
            </p>
          </section>

          {/* 11. Contact */}
          <section>
            <h2 className="text-base sm:text-lg font-medium text-white tracking-tight mb-3">
              11. Contact
            </h2>
            <p className="text-white/70 mb-2">
              If you have any questions, inquiries, or feedback regarding this Privacy Policy or X - One, you can reach out via our official community channels:
            </p>
            <div className="p-4 rounded-lg border border-white/[0.08] bg-white/[0.02] text-xs font-mono text-white/60 space-y-1">
              <div>Entity: <span className="text-white/90">X - One Office</span></div>
              <div>Instagram: <a href="https://www.instagram.com/x_oneoffice/" target="_blank" rel="noopener noreferrer" className="text-[#B8F928] hover:underline">@x_oneoffice</a></div>
              <div>Community: <span className="text-white/90">[Official X-One WhatsApp Community Channel]</span></div>
              <div>Direct Inquiries: <span className="text-white/90">[contact@x-one.office / Official Community Representative]</span></div>
            </div>
          </section>
        </div>

        {/* Bottom Back Navigation */}
        <div className="mt-16 pt-8 border-t border-white/[0.08]">
          <button
            onClick={onBack}
            className="group inline-flex items-center gap-2.5 text-xs font-mono tracking-widest text-white/60 hover:text-[#B8F928] transition-colors focus:outline-none"
            aria-label="Return to X-One main site"
          >
            <ArrowLeft className="w-3.5 h-3.5 transition-transform duration-200 group-hover:-translate-x-1" />
            <span>← Back to X-One</span>
          </button>
        </div>
      </div>
    </article>
  );
};
