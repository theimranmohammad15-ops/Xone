import React, { useRef, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { WHATSAPP_COMMUNITY_URL } from '../data/community';

export const JoinSection: React.FC = () => {
  const buttonRef = useRef<HTMLAnchorElement | null>(null);
  const [btnOffset, setBtnOffset] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    // Magnetic gentle pull (max 5px)
    setBtnOffset({ x: x * 0.12, y: y * 0.12 });
  };

  const handleMouseLeave = () => {
    setBtnOffset({ x: 0, y: 0 });
  };

  return (
    <section
      id="join"
      className="relative w-full py-28 sm:py-36 md:py-48 px-4 sm:px-6 md:px-12 overflow-hidden text-center"
    >
      {/* Seamless transition divider */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.08] to-transparent" />

      <div className="relative z-10 max-w-3xl mx-auto flex flex-col items-center">
        {/* Eyebrow badge */}
        <div className="flex items-center justify-center gap-3 mb-6 sm:mb-8">
          <div className="w-6 h-[1px] bg-[#B8F928]" />
          <span className="text-[10px] sm:text-[11px] font-mono tracking-[0.25em] text-[#B8F928] uppercase">
            GET IN TOUCH
          </span>
          <div className="w-6 h-[1px] bg-[#B8F928]" />
        </div>

        {/* Heading with Strong Editorial Hierarchy */}
        <h2 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl tracking-tight leading-[1.08] mb-6 sm:mb-8">
          <span className="font-light text-white/80 block">BUILD SOMETHING</span>
          <span className="font-semibold text-white block">BEYOND ORDINARY.</span>
        </h2>

        {/* Supporting text */}
        <p className="text-sm sm:text-base md:text-xl text-white/60 font-light max-w-lg leading-relaxed mb-10 sm:mb-12 px-2">
          Whether you&apos;re building a company, a creative project, a SaaS product, or simply your next big idea — X - One is a place to start.
        </p>

        {/* Refined CTA Button */}
        <div className="mb-6 w-full sm:w-auto px-4 sm:px-0">
          <a
            ref={buttonRef}
            href={WHATSAPP_COMMUNITY_URL}
            target="_blank"
            rel="noopener noreferrer"
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="group relative inline-flex items-center justify-center gap-2.5 w-full sm:w-auto px-7 sm:px-8 py-3.5 rounded-full border border-[#B8F928]/45 bg-[#080808] text-xs font-mono tracking-widest text-[#B8F928] shadow-[0_0_16px_rgba(184,249,40,0.12)] hover:shadow-[0_0_28px_rgba(184,249,40,0.34)] hover:border-[#B8F928] hover:bg-[#B8F928] hover:text-[#050505] hover:-translate-y-0.5 transition-all duration-300 focus:outline-none"
            style={{
              transform: `translate3d(${btnOffset.x}px, ${btnOffset.y}px, 0)`,
            }}
          >
            <span>JOIN X - ONE</span>
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
          </a>
        </div>

        {/* Secondary micro descriptor */}
        <div className="text-[11px] font-mono tracking-[0.25em] text-white/35 uppercase">
          MEET. CREATE. BUILD.
        </div>
      </div>
    </section>
  );
};
