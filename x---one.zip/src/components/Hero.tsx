import React, { useState, useEffect, useRef } from 'react';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import { WHATSAPP_COMMUNITY_URL } from '../data/community';

export const Hero: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      // Gentle micro shift (max 6px for architectural stability)
      setMouseOffset({ x: x * 6, y: y * 6 });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section
      id="home"
      ref={containerRef}
      className="relative w-full min-h-screen flex flex-col items-center justify-center text-center px-4 sm:px-6 pt-28 pb-20 overflow-hidden select-none"
    >
      {/* Main Hero Content */}
      <div
        className="relative z-10 max-w-3xl mx-auto flex flex-col items-center transition-transform duration-500 ease-out"
        style={{
          transform: `translate3d(${mouseOffset.x * 0.25}px, ${mouseOffset.y * 0.25}px, 0)`,
        }}
      >
        {/* Understated Brand Eyebrow: X - ONE // SCALE BEYOND IMAGINATION */}
        <div className="text-xs sm:text-sm font-semibold tracking-[0.28em] text-[#B8F928]/80 uppercase mb-4 sm:mb-5 pl-[0.28em]">
          X - ONE &bull; SCALE BEYOND IMAGINATION
        </div>

        {/* Primary Tagline Statement / H1 */}
        <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-[2.65rem] font-light tracking-[0.12em] sm:tracking-[0.16em] text-white/95 uppercase mb-6 leading-snug break-words pl-[0.12em] sm:pl-[0.16em] max-w-2xl">
          X-One — A Space for Founders to Build and Grow
        </h1>

        {/* Subtle, restrained supporting line incorporating local ecosystem context */}
        <p className="text-sm sm:text-base md:text-lg font-light text-white/60 max-w-xl mx-auto leading-relaxed mb-10 px-4">
          An office and founder community connecting creators, developers, and entrepreneurs in Nawada, Bihar with startup collaboration and AI innovation.
        </p>

        {/* Primary Single CTA Button: JOIN X - ONE */}
        <div className="flex items-center justify-center w-full sm:w-auto px-4">
          <a
            href={WHATSAPP_COMMUNITY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="group w-full sm:w-auto px-8 py-3.5 rounded-full bg-[#B8F928] text-[#050505] font-semibold text-xs tracking-wider uppercase hover:bg-[#c6fb54] hover:shadow-[0_0_28px_rgba(184,249,40,0.35)] hover:-translate-y-0.5 transition-all duration-300 transform active:scale-95 inline-flex items-center justify-center gap-2.5 focus:outline-none"
          >
            <span>JOIN X - ONE</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-[#050505] transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>
      </div>

      {/* Editorial bottom scroll prompt */}
      <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40 hover:opacity-90 transition-opacity">
        <span className="text-[9px] font-mono tracking-[0.3em] uppercase text-white/60 pl-[0.3em]">
          SCROLL
        </span>
        <ArrowDown className="w-3.5 h-3.5 text-[#B8F928] animate-bounce" />
      </div>
    </section>
  );
};
