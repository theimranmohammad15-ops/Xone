import React, { useEffect, useState } from 'react';

export const CustomCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [hoveredState, setHoveredState] = useState<'default' | 'pointer' | 'button'>('default');
  const [isVisible, setIsVisible] = useState(false);
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    // Detect touch device or reduced motion preference
    if (
      'ontouchstart' in window ||
      navigator.maxTouchPoints > 0 ||
      (typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
    ) {
      setIsTouch(true);
      return;
    }

    const onMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);

      // Check element under cursor
      const target = e.target as HTMLElement | null;
      if (!target) return;

      const interactiveBtn = target.closest('button, a, [role="button"]');
      const interactiveAny = target.closest('input, select, textarea, [data-cursor="pointer"]');

      if (interactiveBtn) {
        setHoveredState('button');
      } else if (interactiveAny) {
        setHoveredState('pointer');
      } else {
        setHoveredState('default');
      }
    };

    const onMouseLeave = () => setIsVisible(false);
    const onMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseleave', onMouseLeave);
    document.addEventListener('mouseenter', onMouseEnter);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseleave', onMouseLeave);
      document.removeEventListener('mouseenter', onMouseEnter);
    };
  }, [isVisible]);

  if (isTouch || !isVisible) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {/* Outer subtle follower ring */}
      <div
        className={`absolute rounded-full -translate-x-1/2 -translate-y-1/2 transition-transform duration-150 ease-out border ${
          hoveredState === 'button'
            ? 'w-10 h-10 border-[#B8F928] bg-[#B8F928]/10 scale-100'
            : hoveredState === 'pointer'
            ? 'w-7 h-7 border-[#B8F928]/80 bg-[#B8F928]/5 scale-90'
            : 'w-4 h-4 border-white/20 bg-transparent scale-75'
        }`}
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
        }}
      />
      {/* Center pinpoint */}
      <div
        className={`absolute rounded-full -translate-x-1/2 -translate-y-1/2 transition-all duration-75 ${
          hoveredState === 'button'
            ? 'w-1 h-1 bg-[#B8F928]'
            : hoveredState === 'pointer'
            ? 'w-1.5 h-1.5 bg-[#B8F928]'
            : 'w-1.5 h-1.5 bg-white'
        }`}
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
        }}
      />
    </div>
  );
};
