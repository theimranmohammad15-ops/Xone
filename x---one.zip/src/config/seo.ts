/**
 * Centralized Technical SEO & Keyword Configuration for X-One
 * Official Production Domain: https://x-one.netlify.app/
 */

export const CANONICAL_DOMAIN = 'https://x-one.netlify.app';

export interface PageSeoConfig {
  path: string;
  canonicalUrl: string;
  title: string;
  description: string;
  ogTitle: string;
  ogDescription: string;
  isIndexable: boolean;
}

export const PAGES_SEO: Record<'home' | 'privacyPolicy', PageSeoConfig> = {
  home: {
    path: '/',
    canonicalUrl: `${CANONICAL_DOMAIN}/`,
    title: 'X-One – Office for Founders | Nawada, Bihar',
    description:
      'Discover X-One, a founder-focused initiative connecting ideas, creativity, collaboration, and AI innovation in Nawada, Bihar.',
    ogTitle: 'X-One – Office for Founders | Nawada, Bihar',
    ogDescription:
      'Discover X-One, a founder-focused initiative connecting ideas, creativity, collaboration, and AI innovation in Nawada, Bihar.',
    isIndexable: true,
  },
  privacyPolicy: {
    path: '/privacy-policy',
    canonicalUrl: `${CANONICAL_DOMAIN}/privacy-policy`,
    title: 'Privacy Policy – X-One Office for Founders',
    description:
      'Privacy Policy and data transparency practices for the X-One founder community, office space, and digital innovation ecosystem.',
    ogTitle: 'Privacy Policy – X-One Office for Founders',
    ogDescription:
      'Privacy Policy and data transparency practices for the X-One founder community, office space, and digital innovation ecosystem.',
    isIndexable: true,
  },
};

/**
 * Normalizes any route, pathname, or URL into a strict canonical URL:
 * 1. Uses HTTPS protocol and lowercase official host `x-one.netlify.app`.
 * 2. Removes query parameters (e.g. ?utm_source=..., ?ref=...).
 * 3. Removes hash fragments (e.g. #about, #community).
 * 4. Normalizes trailing slashes: preserves trailing slash on root ("https://x-one.netlify.app/"),
 *    removes trailing slash on subpaths ("https://x-one.netlify.app/privacy-policy").
 */
export function normalizeCanonicalUrl(inputPathOrUrl?: string): string {
  if (!inputPathOrUrl) {
    return `${CANONICAL_DOMAIN}/`;
  }

  let pathname = inputPathOrUrl;
  try {
    if (inputPathOrUrl.startsWith('http://') || inputPathOrUrl.startsWith('https://')) {
      const url = new URL(inputPathOrUrl);
      pathname = url.pathname;
    }
  } catch {
    // Keep pathname as-is if URL parsing fails
  }

  const cleanPath = pathname.split('?')[0].split('#')[0].trim().toLowerCase();

  if (!cleanPath || cleanPath === '/' || cleanPath === '') {
    return `${CANONICAL_DOMAIN}/`;
  }

  const normalizedPath = cleanPath.replace(/\/+$/, '');

  if (normalizedPath === '/privacy-policy') {
    return `${CANONICAL_DOMAIN}/privacy-policy`;
  }

  return `${CANONICAL_DOMAIN}${normalizedPath}`;
}

/**
 * Returns the page-specific SEO configuration for the current path
 */
export function getPageSeo(currentPath: string): PageSeoConfig {
  const cleanPath = currentPath.split('?')[0].split('#')[0].trim().toLowerCase().replace(/\/+$/, '');

  if (cleanPath === '/privacy-policy') {
    return PAGES_SEO.privacyPolicy;
  }

  return PAGES_SEO.home;
}
