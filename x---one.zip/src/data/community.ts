/**
 * Centralized Community Configuration for X - One
 * Edit statistics, categories, and member profiles in this single source of truth.
 */

export interface CommunityStat {
  id: string;
  value: number | string;
  suffix?: string;
  label: string;
  sublabel?: string;
}

export interface CommunityCategory {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  tags: string[];
  vibe: string;
}

export interface ProcessStage {
  id: string;
  title: string;
  action: string;
  description: string;
  geometryType: 'points' | 'lines' | 'grid' | 'nodes' | 'rings';
}

export const WHATSAPP_COMMUNITY_URL = 'https://chat.whatsapp.com/KKgYZd3xJwwCb6FL1XDRxK';

export const COMMUNITY_STATS: CommunityStat[] = [
  {
    id: 'founders',
    value: 50,
    suffix: '+',
    label: 'Founders',
  },
  {
    id: 'creators',
    value: 20,
    suffix: '+',
    label: 'Creators',
  },
  {
    id: 'agencies',
    value: 10,
    suffix: '+',
    label: 'Agencies',
  },
];

export const COMMUNITY_CATEGORIES: CommunityCategory[] = [
  {
    id: 'founders',
    number: '01',
    title: 'FOUNDERS',
    subtitle: 'Building the next company',
    description: 'Ambitious operators transforming early insights into defensible businesses, shipping MVPs, and raising capital.',
    tags: ['Early Stage', 'Pre-seed / Seed', 'Venture Builders'],
    vibe: 'Relentless execution',
  },
  {
    id: 'agencies',
    number: '02',
    title: 'SMALL AGENCIES',
    subtitle: 'Independent teams turning ideas into businesses',
    description: 'High-leverage micro-studios executing brand design, full-stack product development, and growth marketing.',
    tags: ['Brand Identity', 'Product Studios', 'Performance'],
    vibe: 'High craft & speed',
  },
  {
    id: 'creators',
    number: '03',
    title: 'CREATORS',
    subtitle: 'Designers, editors, marketers and creative thinkers',
    description: 'Visual storytellers, 3D animators, content architects, and product designers shaping contemporary culture.',
    tags: ['Motion & 3D', 'Editorial', 'Creative Strategy'],
    vibe: 'Cultural foresight',
  },
  {
    id: 'students',
    number: '04',
    title: 'STUDENTS',
    subtitle: 'Young minds learning, experimenting and building',
    description: 'Self-directed learners hacking weekends away, exploring frontiers of technology, design, and experimental tools.',
    tags: ['Curiosity First', 'Hackathons', 'Future Builders'],
    vibe: 'Unbounded optimism',
  },
  {
    id: 'saas',
    number: '05',
    title: 'SAAS BUILDERS',
    subtitle: 'People turning problems into products',
    description: 'Indie makers and technical founders building micro-SaaS, developer utilities, and AI-native workflows.',
    tags: ['Micro-SaaS', 'API Tools', 'Recurring Value'],
    vibe: 'Self-sustainable growth',
  },
  {
    id: 'developers',
    number: '06',
    title: 'DEVELOPERS',
    subtitle: 'Builders creating the technology behind ideas',
    description: 'Systems architects, frontend specialists, and model deployers engineering high-performance digital engines.',
    tags: ['TypeScript / Rust', 'Cloud Native', 'AI Architecture'],
    vibe: 'Code that scales',
  },
];

export const PROCESS_STAGES: ProcessStage[] = [
  {
    id: 'meet',
    title: 'MEET',
    action: 'Small points connect',
    description: 'Enter the community. Collide organically with founders, creators, and engineers who match your curiosity.',
    geometryType: 'points',
  },
  {
    id: 'create',
    title: 'CREATE',
    action: 'New lines appear',
    description: 'Spontaneous whiteboard sessions, shared design drafts, and sparks that turn raw thoughts into tangible prototypes.',
    geometryType: 'lines',
  },
  {
    id: 'build',
    title: 'BUILD',
    action: 'Geometry becomes structured',
    description: 'Focus hours in a low-friction room. Code gets committed, interfaces get styled, and first users get onboarded.',
    geometryType: 'grid',
  },
  {
    id: 'connect',
    title: 'CONNECT',
    action: 'Multiple nodes connect',
    description: 'Link your project to agency partners, beta testers, student talent, and early adopters in the room.',
    geometryType: 'nodes',
  },
  {
    id: 'grow',
    title: 'GROW',
    action: 'Rings expand outward',
    description: 'Compound knowledge, scale ideas beyond their original constraints, and step into global arenas together.',
    geometryType: 'rings',
  },
];

export const FLOATING_KEYWORDS = [
  'FOUNDERS',
  'CREATORS',
  'DEVELOPERS',
  'STUDENTS',
  'ENTREPRENEURS',
  'SAAS BUILDERS',
] as const;
